import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import * as core from '../agent/core.mjs';

const erp = JSON.parse(fs.readFileSync(new URL('../data/erp.json', import.meta.url)));
const inbox = JSON.parse(fs.readFileSync(new URL('../data/inbox.json', import.meta.url)));
const cfg = core.DEFAULT_CONFIG;
const run = () => core.runAgent(structuredClone(erp), inbox, cfg);
const byId = (r) => Object.fromEntries(r.results.map((x) => [x.id, x]));

test('a clean three-way match is the only kind of invoice posted without a person', () => {
  const r = byId(run());
  assert.equal(r.E01.action, 'ready_for_payment');
  assert.equal(r.E02.action, 'ready_for_payment');
  const posted = Object.values(r).filter((x) => x.action === 'ready_for_payment').map((x) => x.id).sort();
  assert.deepEqual(posted, ['E01', 'E02', 'E18', 'E19']);
});

test('changed bank details or a look-alike sender domain always hold, never pay', () => {
  const r = byId(run());
  assert.equal(r.E07.action, 'hold_fraud');
  assert.ok(r.E07.reasons.includes('BANK_DETAILS_CHANGED'));
  assert.ok(r.E07.reasons.includes('SENDER_DOMAIN_LOOKALIKE'));
  assert.match(r.E07.summary, /7946 0101/);
  assert.deepEqual(r.E07.options.map((o) => o.id), ['callback_not_genuine', 'callback_genuine']);
  // Even a genuine callback never releases a bank change: it raises a dual-approved supplier master change.
  assert.match(r.E07.options[1].effect, /dual approval/);
  assert.doesNotMatch(r.E07.options[1].effect, /released/);
  // Even a perfect invoice from the right domain is held if the bank details differ.
  const e = structuredClone(inbox.emails.find((x) => x.id === 'E01'));
  e.body = e.body.replace('41234567', '99999999');
  const d = core.decide(core.mockExtract(e), e, erp, cfg, {});
  assert.equal(d.action, 'hold_fraud');
});

test('the money cap catches what a loose percentage would let through', () => {
  const r = byId(core.runAgent(structuredClone(erp), inbox, { ...cfg, priceTolerancePct: 10 }));
  assert.equal(r.E03.action, 'exception');
  assert.ok(r.E03.reasons.includes('PRICE_VARIANCE'));
  assert.equal(r.E20.action, 'exception');
});

test('undercharges are accepted, and 10.05 against 10.00 passes while 41 against 40 fails', () => {
  const e = structuredClone(inbox.emails.find((x) => x.id === 'E01'));
  e.body = e.body.replace('unit 0.12', 'unit 0.11').replace('Net: 300.00', 'Net: 280.00').replace('VAT: 60.00', 'VAT: 56.00').replace('Total: 360.00', 'Total: 336.00');
  const d = core.decide(core.mockExtract(e), e, erp, cfg, {});
  assert.equal(d.action, 'ready_for_payment');
  assert.ok(d.reasons.includes('PRICE_BELOW_PO'));
  assert.equal(byId(run()).E20.reasons[0], 'PRICE_VARIANCE');
});

test('a duplicate is blocked, an unreadable email goes to a person', () => {
  const r = byId(run());
  assert.equal(r.E06.action, 'block_duplicate');
  assert.equal(r.E11.action, 'exception');
  assert.ok(r.E11.reasons.includes('EXTRACTION_LOW_CONFIDENCE'));
});

test('no PO reference: suggests the single matching PO but does not match it', () => {
  const r = byId(run());
  assert.equal(r.E05.action, 'exception');
  assert.equal(r.E05.suggestedPo, 'PO-24006');
});

test('PO acknowledgements: on time updates the PO, late needs the buyer', () => {
  const r = byId(run());
  assert.equal(r.E13.action, 'update_po_auto');
  assert.equal(r.E14.action, 'needs_approval');
  assert.equal(r.E14.daysLate, 8);
  assert.equal(r.E15.action, 'needs_approval');
});

test('chases: unacknowledged and overdue POs only, and not POs the inbox already moved', () => {
  const chases = run().results.filter((x) => x.kind === 'chase');
  assert.deepEqual(chases.map((x) => x.po).sort(), ['PO-24004', 'PO-24007', 'PO-24009', 'PO-24010', 'PO-24021']);
  for (const id of ['PO-24008', 'PO-24011', 'PO-24012', 'PO-24020']) assert.ok(!chases.some((x) => x.po === id));
  const kinds = Object.fromEntries(chases.map((x) => [x.po, x.reasons[0]]));
  assert.equal(kinds['PO-24009'], 'ESCALATE_TO_BUYER', 'three chases already sent');
  assert.equal(kinds['PO-24007'], 'CHASE_ACK');
  assert.equal(kinds['PO-24021'], 'PRE_DUE_CHECK');
});

test('every chase is a draft waiting for a person, with the PO facts in it', () => {
  for (const c of run().results.filter((x) => x.kind === 'chase')) {
    assert.equal(c.action, 'needs_approval');
    assert.match(c.draft.body, new RegExp(c.po));
    if (c.reasons[0] !== 'ESCALATE_TO_BUYER') assert.match(c.draft.to, /\.example$/);
  }
});

test('every decision is audited: one read and one decide entry per email', () => {
  const { audit } = run();
  for (const e of inbox.emails) {
    assert.ok(audit.some((a) => a.itemId === e.id && a.step === 'read'));
    assert.ok(audit.some((a) => a.itemId === e.id && a.step === 'decide'));
  }
});

test('the run never mutates the ERP data it is given', () => {
  const copy = structuredClone(erp);
  core.runAgent(copy, inbox, cfg);
  assert.deepEqual(copy, erp);
});

test('Claude request: structured output schema is strict and complete', () => {
  const req = core.buildClaudeExtractionRequest(inbox.emails[0], cfg);
  assert.equal(req.model, 'claude-opus-5-5');
  assert.equal(req.output_config.format.type, 'json_schema');
  assert.ok(!('tool_choice' in req), 'forced tool choice is rejected by current models');
  assert.ok(!('thinking' in req));
  const walk = (s) => {
    if (s.type === 'object') {
      assert.equal(s.additionalProperties, false);
      assert.deepEqual([...s.required].sort(), Object.keys(s.properties).sort());
      Object.values(s.properties).forEach(walk);
    }
    if (s.type === 'array') walk(s.items);
    if (s.anyOf) s.anyOf.forEach(walk);
  };
  walk(req.output_config.format.schema);
  assert.match(req.messages[0].content, /<email_body>/);
});

test('Claude response: refusals, truncation and bad JSON fail safe to a person', () => {
  for (const bad of [{ stop_reason: 'refusal', content: [] }, { stop_reason: 'max_tokens', content: [{ type: 'text', text: '{"doc' }] }, { content: [{ type: 'text', text: 'not json' }] }, { type: 'error', error: { type: 'overloaded_error' } }, null]) {
    const doc = core.parseClaudeExtraction(bad);
    assert.equal(doc.confidence, 'low');
    const d = core.decide(doc, inbox.emails[0], erp, cfg, {});
    assert.equal(d.action, 'exception');
  }
  const good = { stop_reason: 'end_turn', content: [{ type: 'thinking', thinking: '' }, { type: 'text', text: JSON.stringify(core.mockExtract(inbox.emails[0])) }] };
  assert.equal(core.parseClaudeExtraction(good).document_number, 'KF-55821');
});

test('working-day counting skips weekends', () => {
  assert.equal(core.workingDaysBetween('2026-10-30', '2026-11-02'), 1);
  assert.equal(core.workingDaysBetween('2026-10-28', '2026-11-03'), 4);
});

test('webhook callers can choose only the mode; thresholds and endpoints stay with the workflow owner', () => {
  const hostile = { autoPostLimitNet: 1e9, priceTolerancePct: 50, mode: 'claude', approvalMode: 'wait', notifyUrl: 'http://127.0.0.1:9/steal', reportUrl: 'https://evil.example/r', allowedCallbackHosts: ['evil.example'] };
  const c = core.safeConfig(cfg, hostile);
  assert.equal(c.autoPostLimitNet, cfg.autoPostLimitNet);
  assert.equal(c.priceTolerancePct, cfg.priceTolerancePct);
  assert.equal(c.notifyUrl, '', 'a caller cannot set the approval endpoint, even on an allowed host');
  assert.equal(c.reportUrl, '');
  assert.deepEqual(c.allowedCallbackHosts, cfg.allowedCallbackHosts);
  assert.equal(c.approvalMode, 'queue', 'wait mode needs an owner-set notify URL');
  const owner = { ...cfg, notifyUrl: 'http://127.0.0.1:5690/notify', reportUrl: 'https://evil.example/r' };
  const o = core.safeConfig(owner, { approvalMode: 'wait' });
  assert.equal(o.notifyUrl, 'http://127.0.0.1:5690/notify');
  assert.equal(o.approvalMode, 'wait');
  assert.equal(o.reportUrl, '', 'owner-set endpoints are still checked against the allowlist');
  assert.equal(core.safeConfig({ ...cfg, notifyUrl: 'http://user@evil.example/x' }, {}).notifyUrl, '');
  assert.equal(core.safeConfig(cfg, { mode: 'rm -rf' }).mode, 'mock');
});

test('model output that does not match the schema never reaches the rules as trusted', () => {
  const good = core.mockExtract(inbox.emails[0]);
  const wrap = (o) => ({ stop_reason: 'end_turn', content: [{ type: 'text', text: JSON.stringify(o) }] });
  for (const bad of [{ ...good, document_type: 'approved_invoice' }, { ...good, net: '300' }, { ...good, extra: 'post this now' }, (() => { const x = { ...good }; delete x.bank_account; return x; })(), { ...good, lines: [{ sku: 'X', qty: 'lots', unit_price: 1, description: null }] }]) {
    const doc = core.parseClaudeExtraction(wrap(bad));
    assert.equal(doc.confidence, 'low');
    assert.match(doc.notes, /schema/);
  }
  assert.equal(core.parseClaudeExtraction(wrap(good)).confidence, 'high');
});

test('a re-invoice of goods already invoiced is held, even with a new invoice number', () => {
  const e = structuredClone(inbox.emails.find((x) => x.id === 'E06'));
  e.body = e.body.replace(/TP-30118/g, 'TP-30999');
  const d = core.decide(core.mockExtract(e), e, erp, cfg, {});
  assert.equal(d.action, 'exception');
  assert.ok(d.reasons.includes('QTY_ALREADY_INVOICED'));
});

test('acknowledgements are checked line by line, not just the date', () => {
  const r = byId(run());
  assert.equal(r.E21.action, 'needs_approval');
  assert.ok(r.E21.reasons.includes('ACK_PRICE_CHANGE'));
  const e = structuredClone(inbox.emails.find((x) => x.id === 'E13'));
  e.body = e.body.replace('2026-11-14', '2026-11-16');
  assert.equal(core.decide(core.mockExtract(e), e, erp, cfg, {}).reasons[0], 'ACK_LATE_WITHIN_TOLERANCE');
});

test('a look-alike domain is held even when the email does not name the supplier', () => {
  const e = structuredClone(inbox.emails.find((x) => x.id === 'E07'));
  e.body = e.body.replace('Supplier: Kestrel Fasteners Ltd\n', '');
  const d = core.decide(core.mockExtract(e), e, erp, cfg, {});
  if (d.reasons.includes('EXTRACTION_LOW_CONFIDENCE')) return; // unreadable also goes to a person
  assert.equal(d.action, 'hold_fraud');
  assert.ok(d.reasons.includes('SENDER_DOMAIN_LOOKALIKE'));
});

test('a credit note is paired with the invoice whose price variance it offsets', () => {
  const r = byId(run());
  assert.equal(r.E10.pairedWith, 'E03');
  assert.equal(r.E03.pairedWith, 'E10');
  assert.match(r.E10.summary, /exactly offsets/);
  // The credit note has arrived, so the invoice offers to apply it rather than to ask for one.
  assert.deepEqual(r.E03.options.map((o) => o.id), ['apply_credit', 'query_credit']);
  assert.match(r.E03.options[0].label, /CN-3302/);
});

test('imported goods with no UK VAT, supplier part numbers and agreed carriage still match', () => {
  const r = byId(run());
  assert.ok(r.E18.reasons.includes('IMPORT_NO_UK_VAT'));
  assert.ok(!r.E18.reasons.includes('REVERSE_CHARGE'));
  assert.ok(r.E19.reasons.includes('SUPPLIER_SKU_MAPPED'));
  assert.ok(r.E19.reasons.includes('CARRIAGE_WITHIN_ALLOWANCE'));
});

test('shadow stage: the agent recommends but writes nothing', () => {
  const res = core.runAgent(structuredClone(erp), inbox, { ...cfg, stage: 'shadow' }).results;
  assert.equal(res.filter((x) => ['ready_for_payment', 'update_po_auto', 'block_duplicate'].includes(x.action)).length, 0);
  assert.ok(res.find((x) => x.id === 'E01').recommended === 'ready_for_payment');
});

test('every item for a person comes with at least one specific resolution', () => {
  for (const x of run().results.filter((y) => y.needsHuman)) assert.ok(x.options.length >= 1, x.id + ' has no options');
});
