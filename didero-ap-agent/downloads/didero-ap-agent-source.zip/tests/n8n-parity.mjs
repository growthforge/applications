// Compares a headless n8n run (`n8n execute --id=<id> --rawOutput`, log lines stripped) with the same rules run
// in Node, and writes eval/n8n-run-mock.json. Usage: node tests/n8n-parity.mjs <exec.json> <n8nVersion> <nodeVersion>
import fs from 'node:fs';
import { DEFAULT_CONFIG, runAgent } from '../agent/core.mjs';

const [execPath, n8nVersion, nodeVersion] = process.argv.slice(2);
const exec = JSON.parse(fs.readFileSync(execPath, 'utf8'));
const runData = exec.data.resultData.runData;
const erp = JSON.parse(fs.readFileSync(new URL('../data/erp.json', import.meta.url)));
const inbox = JSON.parse(fs.readFileSync(new URL('../data/inbox.json', import.meta.url)));

const nodesRun = Object.entries(runData).map(([node, runs]) => ({
  node,
  status: runs[0].executionStatus || (runs[0].error ? 'error' : 'success'),
  items: (runs[0].data?.main || []).map((out) => (out || []).length),
}));
const decided = runData['Decide (rules) and find chases'][0].data.main[0].map((i) => i.json);
const local = runAgent(structuredClone(erp), inbox, DEFAULT_CONFIG).results;
const key = (r) => r.action + '|' + r.reasons.join(',');
const mismatches = local.filter((r) => {
  const n = decided.find((d) => d.id === r.id);
  return !n || key(n) !== key(r);
}).map((r) => r.id);
const metrics = runData['Audit log and metrics'][0].data.main[0][0].json.metrics;

const out = {
  ranAt: exec.startedAt,
  n8nVersion,
  node: nodeVersion,
  how: 'Fresh N8N_USER_FOLDER; n8n import:workflow --input=workflow/didero-ap-agent.n8n.json; n8n execute --id=<id> --rawOutput (manual trigger, mode mock, approvalMode queue). Script: n8n-cycle.sh in the session scratchpad, reproduced in 07_qa.md.',
  error: exec.data.resultData.error || null,
  nodesRun,
  metrics,
  sameCodeCheck: {
    note: 'The n8n Code nodes contain agent/core.mjs, so this checks the workflow wiring, not independent logic.',
    items: local.length,
    identicalDecisions: local.length - mismatches.length,
    mismatches,
  },
};
fs.writeFileSync(new URL('../eval/n8n-run-mock.json', import.meta.url), JSON.stringify(out, null, 2) + '\n');
console.log(`n8n parity: ${out.sameCodeCheck.identicalDecisions}/${out.sameCodeCheck.items} identical; error ${out.error ? 'yes' : 'none'}; ${nodesRun.length} nodes ran`);
