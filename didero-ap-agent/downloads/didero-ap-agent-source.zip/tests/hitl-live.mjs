// Live human-in-the-loop test against a running n8n (n8n start).
// Starts a local "approver" service, triggers the workflow's webhook in approvalMode 'wait', answers each
// approval request by POSTing to the execution's resume URL, and waits for the final run report.
// Usage: node tests/hitl-live.mjs http://127.0.0.1:5680   (n8n base URL; workflow published)
import http from 'node:http';
import fs from 'node:fs';

const base = process.argv[2] || 'http://127.0.0.1:5680';
// The webhook's header-auth secret (a test value from the n8n credential the test cycle imports).
const KEY_NAME = 'x-agent-key';
const KEY = process.env.DIDERO_WEBHOOK_KEY || '';
const PORT = 5690;
// What the test approver decides. Anything not listed is approved.
const decisions = {
  E03: { resolution: 'apply_credit', note: 'CN-3302 offsets the price variance' },
  E07: { resolution: 'callback_not_genuine', note: 'Called Kestrel on the number on file: bank change not genuine' },
  E09: { resolution: 'return_to_sender', note: 'Not our supplier' },
  E11: { resolution: 'request_proper', note: 'Asked for an itemised invoice' },
  // A forged approval: right resume URL, wrong token. It must be ignored.
  E17: { resolution: 'send_reply', note: 'Forged approval', token: 'forged-token' },
};
const log = { notified: [], resumed: [], report: null };

function post(url, body, headers = {}) {
  return fetch(url, { method: 'POST', headers: { 'content-type': 'application/json', ...headers }, body: JSON.stringify(body) });
}
async function resume(url, body) {
  for (let i = 0; i < 20; i++) {
    await new Promise((r) => setTimeout(r, 400));
    const res = await post(url, body).catch(() => null);
    if (res && res.ok) return res.status;
  }
  return 'failed';
}

const done = new Promise((resolve) => {
  const server = http.createServer((req, res) => {
    let raw = '';
    req.on('data', (c) => (raw += c));
    req.on('end', async () => {
      res.writeHead(200, { 'content-type': 'application/json' });
      res.end('{"ok":true}');
      const body = raw ? JSON.parse(raw) : {};
      if (req.url === '/notify') {
        log.notified.push({ itemId: body.itemId, action: body.action, reasons: body.reasons, tokenSource: body.tokenSource });
        const d = { by: 'test approver', token: body.approvalToken, ...(decisions[body.itemId] || { resolution: (body.options && body.options[0] && body.options[0].id) || 'none', note: 'Checked' }) };
        const status = await resume(body.resumeUrl, d);
        log.resumed.push({ itemId: body.itemId, resolution: d.resolution, forged: d.token !== body.approvalToken, status });
      }
      if (req.url === '/report') {
        log.report = body;
        server.close();
        resolve();
      }
    });
  });
  server.listen(PORT, '127.0.0.1');
});

const started = Date.now();
// n8n registers published webhooks shortly after the editor comes up, so retry a 404 for up to 30 seconds.
// The body also tries to redirect approvals and loosen limits; the workflow must ignore all of it.
const hostileBody = { config: { approvalMode: 'wait', notifyUrl: 'http://127.0.0.1:9/steal', reportUrl: 'http://127.0.0.1:9/steal', autoPostLimitNet: 1e9 } };
let unauthenticated;
for (let i = 0; i < 30; i++) {
  unauthenticated = await post(base + '/webhook/didero-ap-agent', hostileBody).catch(() => null);
  if (unauthenticated && unauthenticated.status !== 404) break;
  await new Promise((r) => setTimeout(r, 1000));
}
console.log('without the key', unauthenticated && unauthenticated.status);
const trigger = await post(base + '/webhook/didero-ap-agent', hostileBody, { [KEY_NAME]: KEY });
console.log('with the key', trigger.status);
const timeout = setTimeout(() => { console.error('timed out'); process.exit(1); }, 180000);
await done;
clearTimeout(timeout);
const human = (log.report.audit || []).filter((a) => a.step === 'human decision');
const summary = {
  ranAt: new Date().toISOString(),
  seconds: Math.round((Date.now() - started) / 1000),
  webhookWithoutKeyStatus: unauthenticated && unauthenticated.status,
  webhookWithKeyStatus: trigger.status,
  // The body asked for approvals to go to 127.0.0.1:9; they reached the owner's endpoint instead.
  approvalsWentToOwnerEndpoint: log.notified.length > 0,
  notified: log.notified.length,
  resumedOk: log.resumed.filter((r) => r.status === 200).length,
  humanDecisionsInAudit: human.length,
  resolutions: Object.fromEntries(log.resumed.map((r) => [r.itemId, r.resolution])),
  tokenSources: [...new Set(log.notified.map((n) => n.tokenSource))],
  ignoredForgedDecisions: (log.report.outcomes || []).filter((o) => /Decision ignored/.test(o.outcome || '')).map((o) => o.id),
  metrics: log.report.metrics,
  outcomes: log.report.outcomes,
};
fs.writeFileSync(new URL('../eval/hitl-live-result.json', import.meta.url), JSON.stringify({ summary, log }, null, 2) + '\n');
console.log(JSON.stringify({ withoutKey: summary.webhookWithoutKeyStatus, withKey: summary.webhookWithKeyStatus, notified: summary.notified, resumedOk: summary.resumedOk, humanDecisionsInAudit: summary.humanDecisionsInAudit, ignoredForgedDecisions: summary.ignoredForgedDecisions, tokenSources: summary.tokenSources, seconds: summary.seconds }));
