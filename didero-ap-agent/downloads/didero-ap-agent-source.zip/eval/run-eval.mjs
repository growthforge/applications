// Evaluation runner for the AP and PO-chasing agent.
//   node eval/run-eval.mjs            mock mode (deterministic parser, no key) plus the tolerance sweep
//   ANTHROPIC_API_KEY=... node eval/run-eval.mjs --claude
//                                     also runs extraction through the Messages API with the exact request
//                                     body the n8n HTTP Request node sends (raw HTTP, same headers)
// Writes eval/results.json and eval/results.md.
import fs from 'node:fs';
import { DEFAULT_CONFIG, runAgent, buildClaudeExtractionRequest, parseClaudeExtraction } from '../agent/core.mjs';

const here = (p) => new URL(p, import.meta.url);
const erp = JSON.parse(fs.readFileSync(here('../data/erp.json')));
const inbox = JSON.parse(fs.readFileSync(here('../data/inbox.json')));
const expected = JSON.parse(fs.readFileSync(here('./expected.json')));
const AUTO = new Set(expected.autoActions);

function score(run, label) {
  const byId = Object.fromEntries(run.results.map((r) => [r.id, r]));
  const rows = [];
  let typeOk = 0, actionOk = 0, reasonOk = 0, fieldChecks = 0, fieldOk = 0, falseAuto = 0, falseHuman = 0;
  for (const e of expected.items) {
    const r = byId[e.id];
    if (!r) { rows.push({ id: e.id, missing: true }); continue; }
    const type = r.kind === 'chase' ? 'chase' : r.doc.document_type;
    const tOk = type === e.type;
    const aOk = r.action === e.action;
    const rOk = e.reasonsAnyOf ? e.reasonsAnyOf.some((x) => r.reasons.includes(x)) : e.reasons.every((x) => r.reasons.includes(x));
    if (tOk) typeOk++;
    if (aOk) actionOk++;
    if (rOk) reasonOk++;
    const expAuto = AUTO.has(e.action);
    const gotAuto = AUTO.has(r.action);
    if (!expAuto && gotAuto) falseAuto++;
    if (expAuto && !gotAuto) falseHuman++;
    let fOk = null;
    if (e.fields && r.doc && r.doc.confidence === 'high') {
      fOk = true;
      for (const [k, v] of Object.entries(e.fields)) {
        fieldChecks++;
        const got = k === 'lines' ? r.doc.lines.length : r.doc[k];
        const same = typeof v === 'number' ? Math.abs(Number(got) - v) < 0.005 : got === v;
        if (same) fieldOk++; else fOk = false;
      }
    }
    rows.push({ id: e.id, expectedType: e.type, type, expectedAction: e.action, action: r.action, reasons: r.reasons, typeOk: tOk, actionOk: aOk, reasonOk: rOk, fieldsOk: fOk });
  }
  const n = expected.items.length;
  return {
    label, n, typeOk, actionOk, reasonOk, fieldChecks, fieldOk, falseAuto, falseHuman,
    fraudHeld: run.results.filter((r) => r.action === 'hold_fraud').map((r) => r.id),
    autoActions: run.results.filter((r) => AUTO.has(r.action)).length,
    metrics: run.metrics, rows,
  };
}

async function claudeExtract(cfg) {
  const out = {};
  for (const email of inbox.emails) {
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2026-10-21',
        'anthropic-beta': 'server-side-fallback-2026-07-01',
      },
      body: JSON.stringify(buildClaudeExtractionRequest(email, cfg)),
    });
    out[email.id] = parseClaudeExtraction(await res.json());
  }
  return out;
}

const runs = [];
const base = { ...DEFAULT_CONFIG };
runs.push(score(runAgent(erp, inbox, base), 'Tuned policy, mock extraction (price tolerance 2%)'));
// Tolerance sweep: the tuning step that set the 2% figure.
const sweep = [[0, 50], [2, 50], [10, 50], [10, null]].map(([pct, cap]) => {
  const s = score(runAgent(erp, inbox, { ...base, priceTolerancePct: pct, priceToleranceAbsPerLine: cap === null ? Infinity : cap }), 'Price tolerance ' + pct + '%');
  return { pct, cap: cap === null ? 'none' : cap, actionOk: s.actionOk, falseAuto: s.falseAuto, falseHuman: s.falseHuman, autoActions: s.autoActions, n: s.n, wronglyAuto: s.rows.filter((r) => !r.actionOk && expected.autoActions.includes(r.action)).map((r) => r.id) };
});

const shadow = score(runAgent(erp, inbox, { ...base, stage: 'shadow' }), 'Shadow stage (recommend only)');
let claude = null;
if (process.argv.includes('--claude')) {
  if (!process.env.ANTHROPIC_API_KEY) {
    console.error('Set ANTHROPIC_API_KEY to run Claude extraction.');
    process.exit(2);
  }
  const cfg = { ...base, mode: 'claude' };
  claude = score(runAgent(erp, inbox, cfg, await claudeExtract(cfg)), 'Tuned policy, Claude extraction (' + cfg.model + ', effort ' + cfg.effort + ')');
  runs.push(claude);
}

const result = { generatedAt: new Date().toISOString(), runDate: erp.runDate, runs, sweep, shadow: { autoActions: shadow.autoActions, recommendationsMatchingTunedPolicy: shadow.rows.filter((r) => r.reasonOk).length, n: shadow.n }, claudeRun: claude ? 'ran' : 'not run (no API key in this environment)' };
fs.writeFileSync(here('./results.json'), JSON.stringify(result, null, 2) + '\n');

const pct = (a, b) => (b ? Math.round((a / b) * 100) : 0) + '%';
const md = [
  '# Evaluation results',
  '',
  `Synthetic set: ${expected.items.length} items (21 supplier emails and the PO-chasing job), run date ${erp.runDate}. Labels in eval/expected.json were written by hand from the scenario design. The set is weighted towards exceptions on purpose. It is a regression suite for the policy, labelled by its author, not an independent benchmark.`,
  '',
  '| Run | Type correct | Action correct | Reasons correct | Fields correct | Auto-actions that should have gone to a person | Items sent to a person needlessly | Payment-fraud holds |',
  '|---|---|---|---|---|---|---|---|',
  ...runs.map((s) => `| ${s.label} | ${s.typeOk}/${s.n} | ${s.actionOk}/${s.n} | ${s.reasonOk}/${s.n} | ${s.fieldOk}/${s.fieldChecks} | ${s.falseAuto} | ${s.falseHuman} | ${s.fraudHeld.join(', ') || 'none'} |`),
  '',
  `Claude extraction: ${result.claudeRun}.`,
  '',
  '## Tuning: price tolerance sweep',
  '',
  '| Percentage | Per-line cap (pounds) | Action correct | Auto-actions that should have gone to a person | Items sent to a person needlessly |',
  '|---|---|---|---|---|',
  ...sweep.map((s) => `| ${s.pct}% | ${s.cap} | ${s.actionOk}/${s.n} | ${s.falseAuto}${s.wronglyAuto.length ? ' (' + s.wronglyAuto.join(', ') + ')' : ''} | ${s.falseHuman} |`),
  '',
  '## Per item (tuned policy, mock extraction)',
  '',
  '| Item | Expected | Got | Reasons | OK |',
  '|---|---|---|---|---|',
  ...runs[0].rows.map((r) => `| ${r.id} | ${r.expectedAction} | ${r.action} | ${(r.reasons || []).join(', ')} | ${r.actionOk && r.reasonOk && r.typeOk ? 'yes' : 'NO'} |`),
  '',
].join('\n');
fs.writeFileSync(here('./results.md'), md);
console.log(md.split('\n').slice(0, 22).join('\n'));
console.log('\nAction accuracy (mock): ' + pct(runs[0].actionOk, runs[0].n));
