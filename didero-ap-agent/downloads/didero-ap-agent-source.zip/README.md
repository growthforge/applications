# AP invoice and PO-chasing agent: source and tests

Prepared by Hemanth Vallamkonda as part of an application to Didero. Independent and illustrative. Synthetic data only: no real company, supplier, bank detail or credential is included.

Needs Node.js 22 or later (n8n itself needs Node 24). No packages to install.

- `node --test tests/core.test.mjs`: unit tests for the rules (23 tests).
- `node eval/run-eval.mjs`: the 26-item regression suite, the tolerance sweep and the shadow run; writes `eval/results.md`. Add `--claude` with `ANTHROPIC_API_KEY` set to run the extraction through Claude instead of the parser.
- `node tools/build-workflow.mjs`: regenerates `workflow/didero-ap-agent.n8n.json` from `agent/core.mjs`.
- `node tests/hitl-live.mjs http://127.0.0.1:5680`: the live approval test against a running n8n (see `workflow/README.md`).

`agent/core.mjs` is the single source of the rules: the page, the tests and every Code node in the workflow use it.
