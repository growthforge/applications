// Generates workflow/didero-ap-agent.n8n.json from the tested core (agent/core.mjs) and the synthetic data.
// The Code nodes contain the same functions the unit tests and the eval runner exercise.
import fs from 'node:fs';

const here = (p) => new URL(p, import.meta.url);
const core = fs.readFileSync(here('../agent/core.mjs'), 'utf8').replace(/^export /gm, '');
const erp = JSON.parse(fs.readFileSync(here('../data/erp.json'), 'utf8'));
const inbox = JSON.parse(fs.readFileSync(here('../data/inbox.json'), 'utf8'));

const CORE = '// ---- Agent core: generated from agent/core.mjs (tested with node --test and eval/run-eval.mjs) ----\n' + core + '\n// ---- End of agent core ----\n\n';

const code = (glue) => CORE + glue.trim() + '\n';

const nodes = [];
const connections = {};
let n = 0;
function node(name, type, typeVersion, position, parameters, extra = {}) {
  n += 1;
  nodes.push({ parameters, id: 'a0000000-0000-4000-8000-' + String(n).padStart(12, '0'), name, type, typeVersion, position, ...extra });
  return name;
}
function link(from, to, fromIndex = 0, toIndex = 0) {
  connections[from] = connections[from] || { main: [] };
  while (connections[from].main.length <= fromIndex) connections[from].main.push([]);
  connections[from].main[fromIndex].push({ node: to, type: 'main', index: toIndex });
}
function sticky(name, position, width, height, content, color) {
  node(name, 'n8n-nodes-base.stickyNote', 1, position, { content, height, width, ...(color ? { color } : {}) });
}

// ---------- Notes on the canvas ----------
sticky('About this workflow', [-760, -560], 560, 680,
  '## AP invoice and PO-chasing agent\n**Synthetic data only.** Calder Instruments Ltd and every supplier, invoice and bank detail are fictional. No credentials are included.\n\n**The harness:** Claude or the parser reads each email; written rules decide; a person approves anything risky. The agent stops at *ready for the payment run*; it never releases a payment.\n1. **Trigger and config**\n2. **Read** each email: deterministic parser (default) or Claude (structured output)\n3. **Decide** with rules: three-way match, tolerances, fraud and duplicate checks, auto-post limit, PO chasing\n4. **Act or ask**: safe actions run on a mock ERP; everything else waits for a person\n5. **Audit and metrics**\n\n**Run it:** click Execute workflow. Default `mode` is `mock`, `approvalMode` is `queue`.\n**Use Claude:** add an HTTP Header Auth credential (header `x-api-key`) to the Claude node and set `mode` to `claude` in Config.\n**Webhook:** header authentication is on; attach your own HTTP Header Auth credential. Callers can choose only `mode` and `approvalMode`.\n**Live approvals:** set the approval endpoint in Config or as `DIDERO_NOTIFY_URL` in the n8n environment (allowlisted hosts only), then run with `approvalMode` `wait`. Start n8n with `NODE_FUNCTION_ALLOW_BUILTIN=crypto` for random approval tokens. Each item pauses until the approver POSTs `{"token":"<from the request>","resolution":"<an offered option id>","by":"name","note":"..."}` to its resume URL.\n\nPrepared by Hemanth Vallamkonda for an application to Didero. Independent and illustrative.', 6);
sticky('Note: read', [160, -260], 700, 120, '### 2. Read\nParser or model. A refusal, truncated reply or bad JSON becomes **low confidence**, which the rules always send to a person.', 7);
sticky('Note: decide', [940, -260], 420, 120, '### 3. Decide (rules)\nSame inputs, same decision. The model never sets an action.', 7);
sticky('Note: why the rules repeat', [80, 520], 1320, 150, '### Why the same rules library sits in six Code nodes\nn8n passes only JSON between nodes, and a portable workflow cannot load a shared module (n8n Cloud allows only `crypto` and `moment` in Code nodes). So each Code node carries the same library, generated from one source file (`agent/core.mjs`) by `tools/build-workflow.mjs`: the copies cannot drift, and every node can be read on its own. On self-hosted n8n it could be packaged as a module instead.', 7);
sticky('Note: act or ask', [1440, -260], 900, 120, '### 4. Act or ask\nAuto: post a clean three-way match under the limit, record an on-time PO acknowledgement, block a duplicate, ignore an auto-reply. **Everything else waits for a person.**', 7);

// ---------- 1. Trigger and config ----------
const tManual = node('Run the agent (manual)', 'n8n-nodes-base.manualTrigger', 1, [-160, 120], {});
// The webhook needs header authentication: create an HTTP Header Auth credential (for example header
// x-agent-key with a long random value) and attach it here. Without it, n8n refuses every call.
const tHook = node('Run the agent (webhook)', 'n8n-nodes-base.webhook', 2, [-160, 320], { httpMethod: 'POST', path: 'didero-ap-agent', authentication: 'headerAuth', responseMode: 'onReceived', options: {} },
  { webhookId: 'b7e1d1a2-3c4d-4e5f-8a9b-0c1d2e3f4a5b', credentials: { httpHeaderAuth: { id: 'dideroWebhookKey01', name: 'Didero agent webhook key' } } });
const cfgNode = node('Config', 'n8n-nodes-base.code', 2, [80, 220], { jsCode: code(`
// Settings for this run. The workflow owner sets the approval and report endpoints, here or in the n8n
// environment (DIDERO_NOTIFY_URL, DIDERO_REPORT_URL); both must be on a host in allowedCallbackHosts.
// A webhook caller (header-authenticated) may choose only mode and approvalMode. Thresholds are set here.
const owner = { notifyUrl: '', reportUrl: '' };
try {
  owner.notifyUrl = $env.DIDERO_NOTIFY_URL || owner.notifyUrl;
  owner.reportUrl = $env.DIDERO_REPORT_URL || owner.reportUrl;
} catch (e) {
  // Environment access is blocked on this instance: use the values above.
}
const overrides = ($json.body && $json.body.config) || {};
const config = safeConfig({ ...DEFAULT_CONFIG, ...owner }, overrides);
return [{ json: { config } }];
`) });
link(tManual, cfgNode);
link(tHook, cfgNode);

const load = node('Load synthetic ERP and inbox', 'n8n-nodes-base.code', 2, [300, 220], { jsCode: `// Synthetic data, embedded so the workflow runs with no external systems.
// In a real deployment this is an email trigger plus ERP lookups through connectors or an API.
const erp = ${JSON.stringify(erp)};
const inbox = ${JSON.stringify(inbox)};
const config = $('Config').first().json.config;
return inbox.emails.map((email) => ({ json: { email, config } }));
` });
link(cfgNode, load);

// ---------- 2. Read ----------
const modeSwitch = node('Parser or model?', 'n8n-nodes-base.switch', 3.2, [520, 220], { mode: 'expression', numberOutputs: 2, output: "={{ $json.config.mode === 'claude' ? 1 : 0 }}" });
link(load, modeSwitch);
const parser = node('Read email (parser)', 'n8n-nodes-base.code', 2, [760, 100], { jsCode: code(`
return $input.all().map((item) => ({ json: { ...item.json, doc: mockExtract(item.json.email), readBy: 'parser' } }));
`) });
link(modeSwitch, parser, 0);
const buildReq = node('Build Claude request', 'n8n-nodes-base.code', 2, [760, 340], { jsCode: code(`
return $input.all().map((item) => ({ json: { ...item.json, request: buildClaudeExtractionRequest(item.json.email, item.json.config) } }));
`) });
link(modeSwitch, buildReq, 1);
const claude = node('Claude: classify and extract', 'n8n-nodes-base.httpRequest', 4.2, [980, 340], {
  method: 'POST',
  url: 'https://api.anthropic.com/v1/messages',
  authentication: 'genericCredentialType',
  genericAuthType: 'httpHeaderAuth',
  sendHeaders: true,
  headerParameters: { parameters: [{ name: 'anthropic-version', value: '2026-10-21' }, { name: 'anthropic-beta', value: 'server-side-fallback-2026-07-01' }, { name: 'content-type', value: 'application/json' }] },
  sendBody: true,
  specifyBody: 'json',
  jsonBody: '={{ JSON.stringify($json.request) }}',
  options: { response: { response: { neverError: true } } },
}, { onError: 'continueRegularOutput' });
link(buildReq, claude);
const parseClaude = node('Parse Claude output (fail safe)', 'n8n-nodes-base.code', 2, [1200, 340], { jsCode: code(`
const sent = $('Build Claude request').all();
return $input.all().map((item, i) => ({ json: { email: sent[i].json.email, config: sent[i].json.config, doc: parseClaudeExtraction(item.json), readBy: 'model' } }));
`) });
link(claude, parseClaude);

// ---------- 3. Decide ----------
const decideNode = node('Decide (rules) and find chases', 'n8n-nodes-base.code', 2, [1180, 100], { jsCode: code(`
// One pass over every email in arrival order, so duplicates and partial invoicing within a run are caught,
// then the PO-chasing job runs on the updated state. Nothing here writes anywhere: it only proposes.
const erp = ${JSON.stringify(erp)};
const items = $input.all().map((i) => i.json);
const config = items.length ? items[0].config : DEFAULT_CONFIG;
const extracted = Object.fromEntries(items.map((i) => [i.email.id, i.doc]));
const inbox = { emails: items.map((i) => i.email) };
const run = runAgent(erp, inbox, { ...config, mode: items.some((i) => i.readBy === 'model') ? 'claude' : 'mock' }, extracted);
// Authorisation for a decision is n8n's own: each resume URL carries an HMAC signature from the instance secret.
// On top of that, each item gets a random token tying a decision to that item, so a decision cannot be replayed
// onto another item. Start n8n with NODE_FUNCTION_ALLOW_BUILTIN=crypto so the token comes from crypto.randomBytes.
// Without it the token is a weaker correlation id; the signed resume URL is still required either way.
let rand = null;
try { rand = require('crypto').randomBytes; } catch (e) { rand = null; }
const token = (id) => (rand ? rand(16).toString('hex')
  : globalThis.crypto && globalThis.crypto.randomUUID ? globalThis.crypto.randomUUID()
  : [$execution.id, id, Math.random().toString(36).slice(2), Math.random().toString(36).slice(2)].join('-'));
const tokenSource = rand ? 'crypto.randomBytes' : globalThis.crypto && globalThis.crypto.randomUUID ? 'crypto.randomUUID' : 'fallback correlation id';
return run.results.map((r) => ({ json: { ...r, config, approvalToken: r.needsHuman ? token(r.id) : undefined, tokenSource: r.needsHuman ? tokenSource : undefined, audit: run.audit.filter((a) => a.itemId === r.id) } }));
`) });
link(parser, decideNode);
link(parseClaude, decideNode);

// ---------- 4. Act or ask ----------
const route = node('Safe to act alone?', 'n8n-nodes-base.switch', 3.2, [1420, 100], { mode: 'expression', numberOutputs: 2, output: '={{ $json.needsHuman ? 1 : 0 }}' });
link(decideNode, route);
const auto = node('Apply safe actions (mock ERP)', 'n8n-nodes-base.code', 2, [1680, -40], { jsCode: `// Mock ERP: records what would be written. Swap for the ERP connector in a real deployment.
return $input.all().map((item) => {
  const r = item.json;
  const what = r.action === 'ready_for_payment' ? 'Marked ' + r.erpPosting.number + ' ready for the payment run (' + r.erpPosting.currency + ' ' + r.erpPosting.total + '); payment is released by finance'
    : r.action === 'update_po_auto' ? 'Set ' + r.erpChange.po + ' confirmed date to ' + r.erpChange.to
    : r.action === 'block_duplicate' ? 'Blocked duplicate; nothing posted'
    : 'No action';
  return { json: { ...r, outcome: what, decidedBy: 'rules', audit: [...r.audit, { at: new Date().toISOString(), itemId: r.id, actor: 'agent', step: 'act', detail: what }] } };
});
` });
link(route, auto, 0);
const approvalMode = node('Queue or wait?', 'n8n-nodes-base.switch', 3.2, [1680, 220], { mode: 'expression', numberOutputs: 2, output: "={{ $json.config.approvalMode === 'wait' ? 1 : 0 }}" });
link(route, approvalMode, 1);
const queue = node('Approval queue (nothing sent)', 'n8n-nodes-base.code', 2, [1940, 120], { jsCode: `// Queue mode: list each item for review. Nothing is posted, changed or sent.
return $input.all().map((item) => ({ json: { ...item.json, outcome: 'Waiting for a person: ' + (item.json.summary || item.json.reasons.join(', ')), decidedBy: 'pending' } }));
` });
link(approvalMode, queue, 0);
const loop = node('One approval at a time', 'n8n-nodes-base.splitInBatches', 3, [1940, 360], { batchSize: 1, options: {} });
link(approvalMode, loop, 1);
const notify = node('Notify approver', 'n8n-nodes-base.httpRequest', 4.2, [2180, 460], {
  method: 'POST',
  url: '={{ $json.config.notifyUrl }}',
  sendBody: true,
  specifyBody: 'json',
  jsonBody: '={{ JSON.stringify({ itemId: $json.id, action: $json.action, reasons: $json.reasons, summary: $json.summary, draft: $json.draft, draftReply: $json.draftReply, options: $json.options, phoneOnFile: $json.phoneOnFile, approvalToken: $json.approvalToken, tokenSource: $json.tokenSource, resumeUrl: $execution.resumeUrl }) }}',
  options: {},
});
link(loop, notify, 1);
const wait = node('Wait for the decision', 'n8n-nodes-base.wait', 1.1, [2400, 460], { resume: 'webhook', httpMethod: 'POST', options: {} }, { webhookId: 'c8f2e2b3-4d5e-4f6a-9b0c-1d2e3f4a5b6c' });
link(notify, wait);
const record = node('Record the decision', 'n8n-nodes-base.code', 2, [2620, 460], { jsCode: `// The approver's answer arrives as the Wait node's webhook body: { token, resolution, by, note }.
// It is applied only if the token matches and the resolution is one of the options offered for this item.
const item = $('One approval at a time').first().json;
const body = $json.body || {};
const tokenOk = !!item.approvalToken && body.token === item.approvalToken;
const option = (item.options || []).find((o) => o.id === body.resolution);
const what = !tokenOk ? 'Decision ignored: missing or wrong approval token; nothing done'
  : !option ? 'Decision ignored: not one of the offered resolutions; nothing done'
  : option.effect + ' (simulated)';
const by = tokenOk ? (body.by || 'approver') : 'unverified caller';
return [{ json: { ...item, outcome: what, resolution: option && tokenOk ? option.id : null, decidedBy: by, decisionNote: body.note || '', audit: [...item.audit, { at: new Date().toISOString(), itemId: item.id, actor: by, step: 'human decision', detail: (option && tokenOk ? option.label : 'ignored') + (body.note ? ': ' + body.note : '') }] } }];
` });
link(wait, record);
link(record, loop);

// ---------- 5. Audit and metrics ----------
const merge = node('All outcomes', 'n8n-nodes-base.merge', 3, [2880, 120], { numberInputs: 3 });
link(auto, merge, 0, 0);
link(queue, merge, 0, 1);
link(loop, merge, 0, 2);
const report = node('Audit log and metrics', 'n8n-nodes-base.code', 2, [3120, 120], { jsCode: code(`
const results = $input.all().map((i) => i.json);
const metrics = computeMetrics(results);
const audit = results.flatMap((r) => r.audit || []);
return [{ json: { metrics, audit, outcomes: results.map((r) => ({ id: r.id, action: r.action, reasons: r.reasons, outcome: r.outcome, decidedBy: r.decidedBy })) } }];
`) });
link(merge, report);
const reportSwitch = node('Send a run report?', 'n8n-nodes-base.switch', 3.2, [3360, 120], { mode: 'expression', numberOutputs: 2, output: "={{ $('Config').first().json.config.reportUrl ? 1 : 0 }}" });
link(report, reportSwitch);
const sendReport = node('Send run report', 'n8n-nodes-base.httpRequest', 4.2, [3600, 220], {
  method: 'POST',
  url: "={{ $('Config').first().json.config.reportUrl }}",
  sendBody: true,
  specifyBody: 'json',
  jsonBody: '={{ JSON.stringify($json) }}',
  options: {},
});
link(reportSwitch, sendReport, 1);
sticky('Note: audit', [2840, -260], 520, 120, '### 5. Audit and metrics\nEvery extract, decision, action and human decision is logged with who made it. Metrics: touchless rate, exceptions by reason, chases drafted.', 7);

const workflow = {
  name: 'Didero AP and PO-chasing agent (synthetic)',
  nodes,
  connections,
  pinData: {},
  settings: { executionOrder: 'v1' },
  meta: { templateCredsSetupCompleted: true },
  tags: [],
};
fs.mkdirSync(here('../workflow/'), { recursive: true });
fs.writeFileSync(here('../workflow/didero-ap-agent.n8n.json'), JSON.stringify(workflow, null, 2) + '\n');
console.log('workflow written:', nodes.length, 'nodes,', Object.keys(connections).length, 'connected sources');
