# Questionnaire desk kit

Illustrative data: fictional vendor. Larkfield Systems, its answer library and the buyer Harwick Retail Group are made up. Independent work by Hemanth Vallamkonda; not affiliated with any vendor named in the page.

## What is here
- `agent/core.mjs`: the rules and checks. The page, the tests and the n8n workflow run this one file.
- `data/`: the approved-answer library (29 entries, with owners, review dates and evidence rules), the buyer's questionnaire (36 questions) and a held-out set (12 questions written after the rules were frozen).
- `eval/`: expected outcomes written by hand before the model runs, the scorer (`run-eval.mjs`), and the results, including the n8n parity run and the live owner-approval test.
- `runs/`: `input.md` (exactly what the model gets for each question that passes the rules) and three recorded Claude runs.
- `workflow/questionnaire-desk.n8n.json`: the n8n workflow (26 working nodes and 5 notes). `tools/build-workflow.mjs` regenerates it from the core.

## Run it
```sh
node --test tests/core.test.mjs      # the rules and checks
node eval/run-eval.mjs               # score the recorded runs, break every ready draft on purpose
node tools/build-draft-input.mjs     # rebuild the model input after a library change
```

## Use it as an acceptance test
The questionnaire, the held-out set and their expected outcomes work against any questionnaire tool: run the questions through it and compare its answers and routes with `eval/expected.json`. A tool that answers a blocked or unsupported question, cites a draft entry or changes a number has failed, whoever made it.

## In n8n
1. Create a Header Auth credential named "Questionnaire desk webhook key" with header `x-desk-key`.
2. Import the workflow and publish it.
3. Set `DESK_NOTIFY_URL` and `DESK_REPORT_URL` (allowed hosts only; see `allowedCallbackHosts` in the core).
4. For live drafting add an HTTP Header Auth credential with header `x-api-key` and call with `{"config": {"mode": "claude"}}`.
Owner decisions arrive on n8n's signed resume URL with a per-question token, and are recorded against the owner the request was sent to.
