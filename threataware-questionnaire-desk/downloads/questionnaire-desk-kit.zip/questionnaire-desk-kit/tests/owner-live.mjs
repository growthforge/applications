// Live owner-approval test against a running n8n (n8n start, workflow published).
// Starts a local "owner" service, calls the desk's webhook in approvalMode 'wait', answers each owner request
// by POSTing to the execution's signed resume URL, and waits for the final report.
// Usage: DESK_WEBHOOK_KEY=<test key> node tests/owner-live.mjs http://127.0.0.1:5680
import http from 'node:http';
import fs from 'node:fs';

const base = process.argv[2] || 'http://127.0.0.1:5680';
const KEY_NAME = 'x-desk-key';
const KEY = process.env.DESK_WEBHOOK_KEY || '';
const PORT = 5691;
// What the test owners decide. Anything not listed is "do not answer in writing".
const decisions = {
  Q09: { decision: 'answer', answer: 'Not today. Encryption keys are managed by us in our cloud provider\'s key management service.', by: 'Head of Engineering (test)' },
  Q16: { decision: 'answer', answer: 'No. We host in the UK, the EU or the US only.', by: 'Head of Security (test)' },
  Q23: { decision: 'answer', answer: 'Our last full failover test was in March 2026; the next is scheduled and the report is shared under NDA.', by: 'Head of Engineering (test)' },
  // A forged decision: the right resume URL, the wrong token. It must be ignored.
  Q33: { decision: 'answer', answer: 'Yes, uncapped.', by: 'someone', token: 'forged-token' },
};
const log = { notified: [], resumed: [], refusedWithoutSignature: null, report: null };
const post = (url, body, headers = {}) => fetch(url, { method: 'POST', headers: { 'content-type': 'application/json', ...headers }, body: JSON.stringify(body) });
async function resume(url, body) {
  // First without the URL's signature: n8n must refuse it.
  if (log.refusedWithoutSignature === null) log.refusedWithoutSignature = await post(url.replace(/\?signature=[^&]+/, ''), body).then((r) => r.status).catch(() => 'error');
  for (let i = 0; i < 20; i++) {
    await new Promise((r) => setTimeout(r, 400));
    const res = await post(url, body).catch(() => null);
    if (res && res.ok) return res.status;
  }
  return 'failed';
}

const done = new Promise((resolve) => {
  const server = http.createServer((req, res) => {
    let raw = '';
    req.on('data', (c) => (raw += c));
    req.on('end', async () => {
      res.writeHead(200, { 'content-type': 'application/json' }).end('{"ok":true}');
      const body = raw ? JSON.parse(raw) : {};
      if (req.url === '/notify') {
        log.notified.push({ id: body.id, owner: body.owner, reasons: (body.reasons || []).map((r) => r.code), options: (body.options || []).map((o) => o.id), tokenSource: body.tokenSource });
        const d = decisions[body.id] || { decision: 'discuss', by: body.owner + ' (test)' };
        const status = await resume(body.resumeUrl, { token: d.token || body.approvalToken, decision: d.decision, answer: d.answer, by: d.by });
        log.resumed.push({ id: body.id, status });
      } else if (req.url === '/report') {
        log.report = body;
        server.close();
        resolve();
      }
    });
  });
  server.listen(PORT, '127.0.0.1');
});

const hook = base + '/webhook/questionnaire-desk';
let auth = 0;
for (let i = 0; i < 30 && auth !== 200; i++) {
  auth = await post(hook, { config: { approvalMode: 'wait', model: 'not-allowed' } }, { [KEY_NAME]: KEY }).then((r) => r.status).catch(() => 0);
  if (auth !== 200) await new Promise((r) => setTimeout(r, 1000));
}
// Once the webhook is registered: the same call without the key must be refused (and start nothing).
const unauth = await post(hook, { config: { approvalMode: 'wait' } }).then((r) => r.status).catch(() => 'error');
const timer = setTimeout(() => { console.log('timed out'); process.exit(1); }, 180000);
await done;
clearTimeout(timer);
const s = log.report.summary;
const rows = Object.fromEntries(log.report.rows.map((r) => [r.id, r]));
const summary = {
  withoutKey: unauth, withKey: auth, resumeWithoutSignature: log.refusedWithoutSignature,
  notified: log.notified.length, resumedOk: log.resumed.filter((r) => r.status === 200).length,
  ready: s.ready, waiting: s.waiting, toLibraryReview: s.toLibraryReview,
  forgedIgnored: rows.Q33 && rows.Q33.status.startsWith('Waiting'),
  owners: s.byOwner, tokenSources: [...new Set(log.notified.map((x) => x.tokenSource))],
  // A decision is recorded against the owner its link was sent to, whatever name the caller signs with.
  decisionsRecordedAgainstRoutedOwner: log.report.audit.filter((a) => a.step === 'owner decision' && a.actor !== 'unverified caller').every((a) => a.actor === (rows[a.id] && rows[a.id].owner)),
};
fs.writeFileSync(new URL('../eval/owner-live-result.json', import.meta.url), JSON.stringify({ ranAt: new Date().toISOString(), summary, notified: log.notified, resumed: log.resumed, rows: log.report.rows, audit: log.report.audit }, null, 2) + '\n');
console.log(JSON.stringify(summary));
