// Compares a headless n8n run of the workflow (recorded mode, queue) with the same engine in Node on the same
// recorded drafts, row by row, and writes eval/n8n-run.json.
// Usage: node tests/n8n-parity.mjs <clean exec.json> <n8nVersion> <nodeVersion>
import fs from 'node:fs';
import * as core from '../agent/core.mjs';

const [execPath, n8nVersion, nodeVersion] = process.argv.slice(2);
const exec = JSON.parse(fs.readFileSync(execPath, 'utf8'));
const runData = exec.data.resultData.runData;
const read = (p) => JSON.parse(fs.readFileSync(new URL('../' + p, import.meta.url)));
const library = read('data/library.json');
const rows = read('data/questionnaire.json').rows;
const recorded = read('runs/sonnet-run1.json').results;
const local = core.answerAll(rows, { library, index: core.buildIndex(library), today: library.today }, (r) => recorded[r.id] || { error: 'none' }).results.map(core.finalRow);
const out = runData['Answered questionnaire and audit log'][0].data.main[0][0].json;
const key = (r) => [r.status.replace(/^Waiting for .*/, 'Waiting'), r.response, r.answer, r.sources.join('+'), r.reasons.join('+')].join('|');
const remote = Object.fromEntries(out.rows.map((r) => [r.id, r]));
const mismatches = local.filter((r) => !remote[r.id] || key(remote[r.id]) !== key(r) || (remote[r.id].owner || null) !== (r.owner || null)).map((r) => r.id);
const nodes = Object.entries(runData).map(([node, runs]) => ({ node, status: runs[0].executionStatus || 'success' }));
const result = { ranAt: new Date().toISOString(), n8nVersion, node: nodeVersion, mode: 'recorded (sonnet-run1), approvalMode queue', rows: out.rows.length, identical: local.length - mismatches.length, mismatches, nodesRun: nodes.length, errors: nodes.filter((x) => x.status !== 'success').map((x) => x.node), summary: out.summary };
fs.writeFileSync(new URL('../eval/n8n-run.json', import.meta.url), JSON.stringify(result, null, 2) + '\n');
console.log(`n8n parity: ${result.identical}/${result.rows} identical; errors ${result.errors.length ? result.errors.join(', ') : 'none'}; ${result.nodesRun} nodes ran`);
