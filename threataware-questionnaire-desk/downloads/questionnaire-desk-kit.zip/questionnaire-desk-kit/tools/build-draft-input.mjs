// Writes runs/input.md: one job per question that passes triage (the questionnaire, then the held-out set),
// each job exactly what the drafting model receives (system prompt, approved entries, the buyer's question)
// plus the JSON schema to return. Rows stopped by triage never reach a model, so they are not in the file.
import fs from 'node:fs';
import * as core from '../agent/core.mjs';

const read = (p) => JSON.parse(fs.readFileSync(new URL('../' + p, import.meta.url)));
const library = read('data/library.json');
const rows = [...read('data/questionnaire.json').rows, ...read('data/holdout.json').rows];
const index = core.buildIndex(library);
const jobs = [];
for (const r of rows) {
  const hits = core.retrieve(index, library, r.question);
  if (core.triage(r.question, hits, library.today).length) continue;
  const given = core.usableHits(hits, library.today);
  jobs.push(`===== JOB ${r.id} =====\n## System\n${core.DRAFT_SYSTEM}\n\n## User\n${core.draftInput(r.question, given)}\n\n## Return only JSON matching this schema\n${JSON.stringify(core.DRAFT_SCHEMA)}\n===== END JOB ${r.id} =====`);
}
// --stdout prints the jobs without the header, so a test can confirm the recorded runs' input is still what the
// workflow would send today.
if (process.argv.includes('--stdout')) process.stdout.write(jobs.join('\n\n') + '\n');
else {
  fs.mkdirSync(new URL('../runs/', import.meta.url), { recursive: true });
  fs.writeFileSync(new URL('../runs/input.md', import.meta.url), `<!-- policy ${core.POLICY.version}; ${jobs.length} jobs -->\n` + jobs.join('\n\n') + '\n');
  console.log('wrote runs/input.md with', jobs.length, 'jobs');
}
