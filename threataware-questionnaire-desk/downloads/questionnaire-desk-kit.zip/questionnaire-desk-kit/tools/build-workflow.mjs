// Generates workflow/questionnaire-desk.n8n.json from the tested core (agent/core.mjs), the synthetic library and
// questionnaire, and one recorded Claude run (so the workflow runs with no API key in 'recorded' mode).
import fs from 'node:fs';

const here = (p) => new URL(p, import.meta.url);
const core = fs.readFileSync(here('../agent/core.mjs'), 'utf8').replace(/^export /gm, '');
const library = JSON.parse(fs.readFileSync(here('../data/library.json'), 'utf8'));
const questionnaire = JSON.parse(fs.readFileSync(here('../data/questionnaire.json'), 'utf8'));
const recordedFile = here('../runs/sonnet-run1.json');
const recorded = fs.existsSync(recordedFile) ? JSON.parse(fs.readFileSync(recordedFile, 'utf8')).results : {};

const CORE = '// ---- Desk core: generated from agent/core.mjs (tested with node --test and eval/run-eval.mjs) ----\n' + core + '\n// ---- End of desk core ----\n\n';
const code = (glue) => CORE + glue.trim() + '\n';

const nodes = [];
const connections = {};
let n = 0;
function node(name, type, typeVersion, position, parameters, extra = {}) {
  n += 1;
  nodes.push({ parameters, id: 'b1000000-0000-4000-8000-' + String(n).padStart(12, '0'), name, type, typeVersion, position, ...extra });
  return name;
}
function link(from, to, fromIndex = 0, toIndex = 0) {
  connections[from] = connections[from] || { main: [] };
  while (connections[from].main.length <= fromIndex) connections[from].main.push([]);
  connections[from].main[fromIndex].push({ node: to, type: 'main', index: toIndex });
}
function sticky(name, position, width, height, content, color) {
  node(name, 'n8n-nodes-base.stickyNote', 1, position, { content, height, width, ...(color ? { color } : {}) });
}

sticky('About this workflow', [-780, -560], 560, 700,
  '## Security questionnaire desk\n**Illustrative data: fictional vendor.** Larkfield Systems, its library and the buyer Harwick Retail Group are made up. No credentials are included.\n\n'
  + '**How it decides:** retrieval finds the approved library entries; rules stop contract, pricing, incident and roadmap questions, instructions aimed at AI tools, expired or unapproved answers, named standards or places no entry mentions, and questions no entry covers. Claude gets only approved, in-date entries, drafts from them and quotes them. Code then checks every quote, the yes or no, every number with its unit, every name and link, the length, and that each part of the question is covered; the answer sent is built by code from the whole approved sentences quoted, never from what the model wrote. Anything that fails goes to a named owner.\n\n'
  + '**Modes:** `recorded` uses a recorded Claude run (no key needed); `claude` calls the Messages API (add an HTTP Header Auth credential with header `x-api-key`). `approvalMode` `queue` lists what needs an owner; `wait` pauses for each decision through n8n\'s signed resume URL.\n\n'
  + '**Webhook:** header-authenticated (`x-desk-key`). An owner\'s decision counts only on n8n\'s signed resume URL and with that question\'s random token. A caller may send `rows` (the buyer\'s questions) and choose `mode` and `approvalMode`, nothing else.', 4);
sticky('Note: find and stop', [140, -260], 640, 120, '### 1. Find the approved answer, or stop\nRules run before any model: blocked topics, AI-directed instructions, no close entry, expired or draft entries, standards or places the library never mentions.', 7);
sticky('Note: draft and check', [880, -260], 900, 120, '### 2. Draft, then check in code\nThe model quotes approved entries word for word. A quote not in the entry, a draft entry cited, a flipped yes or no, a number, unit, name or link the source lacks, an uncovered part or low confidence sends the question to its owner.', 7);
sticky('Note: owners', [1900, -260], 900, 120, '### 3. Owners decide\nEach question that needs a person goes to its named owner. A decision counts only with the right token on n8n\'s signed resume URL, and is recorded against the owner the link was sent to.', 7);

// ---------- Trigger and config ----------
const tManual = node('Answer the sample questionnaire (manual)', 'n8n-nodes-base.manualTrigger', 1, [-160, 120], {});
const tHook = node('Questionnaire in (webhook)', 'n8n-nodes-base.webhook', 2, [-160, 320], { httpMethod: 'POST', path: 'questionnaire-desk', authentication: 'headerAuth', responseMode: 'onReceived', options: {} },
  { webhookId: 'd3a1c2b4-5e6f-4a7b-8c9d-0e1f2a3b4c5d', credentials: { httpHeaderAuth: { id: 'deskWebhookKey01', name: 'Questionnaire desk webhook key' } } });
const cfg = node('Config', 'n8n-nodes-base.code', 2, [80, 220], { jsCode: code(`
// The workflow owner sets the owner-notification and report endpoints here or in the environment
// (DESK_NOTIFY_URL, DESK_REPORT_URL); they must be on a host in allowedCallbackHosts.
const owner = { notifyUrl: '', reportUrl: '' };
try {
  owner.notifyUrl = $env.DESK_NOTIFY_URL || owner.notifyUrl;
  owner.reportUrl = $env.DESK_REPORT_URL || owner.reportUrl;
} catch (e) {
  // Environment access is blocked on this instance: use the values above.
}
const body = $json.body || {};
const config = safeConfig({ ...DEFAULT_CONFIG, ...owner }, body.config || {});
return [{ json: { config, rows: cleanRows(body.rows) } }];
`) });
link(tManual, cfg);
link(tHook, cfg);

const load = node('Load library and questionnaire', 'n8n-nodes-base.code', 2, [300, 220], { jsCode: `// Synthetic library and questionnaire, embedded so the workflow runs with no external systems.
// In use: the library comes from the trust centre or a Data Table, and the questionnaire from the rep's upload.
const library = ${JSON.stringify(library)};
const questionnaire = ${JSON.stringify(questionnaire)};
const { config, rows } = $json;
return (rows && rows.length ? rows : questionnaire.rows).map((row) => ({ json: { row, config, library } }));
` });
link(cfg, load);

// ---------- 1. Find and stop ----------
const triageNode = node('Find approved entries and apply the rules', 'n8n-nodes-base.code', 2, [520, 220], { jsCode: code(`
const items = $input.all();
const library = items[0].json.library;
const index = buildIndex(library);
return items.map(({ json }) => {
  const hits = retrieve(index, library, json.row.question);
  const pre = triage(json.row.question, hits, library.today);
  return { json: { row: json.row, config: json.config, hits, given: usableHits(hits, library.today), today: library.today, pre } };
});
`) });
link(load, triageNode);
const stopped = node('Stopped by a rule?', 'n8n-nodes-base.switch', 3.2, [740, 220], { mode: 'expression', numberOutputs: 2, output: '={{ $json.pre.length ? 0 : 1 }}' });
link(triageNode, stopped);
const toOwner = node('Route to the owner (rule)', 'n8n-nodes-base.code', 2, [980, 40], { jsCode: code(`
return $input.all().map(({ json }) => {
  const r = { id: json.row.id, section: json.row.section, question: json.row.question, hits: json.hits.map((h) => ({ id: h.id, score: h.score })), route: 'owner', reasons: json.pre, owner: json.pre[0].owner, draft: null, checks: [] };
  return { json: { ...r, config: json.config, audit: [auditEntry(new Date().toISOString(), r.id, 'rules', 'stopped', json.pre.map((p) => p.code).join(', '))] } };
});
`) });
link(stopped, toOwner, 0);

// ---------- 2. Draft and check ----------
const modeSwitch = node('Recorded or Claude?', 'n8n-nodes-base.switch', 3.2, [980, 320], { mode: 'expression', numberOutputs: 2, output: "={{ $json.config.mode === 'claude' ? 1 : 0 }}" });
link(stopped, modeSwitch, 1);
const useRecorded = node('Use the recorded Claude draft', 'n8n-nodes-base.code', 2, [1200, 220], { jsCode: `// Drafts recorded from a Claude run on this questionnaire (eval/run-eval.mjs scores them).
const recorded = ${JSON.stringify(recorded)};
return $input.all().map(({ json }) => ({ json: { ...json, draft: recorded[json.row.id] || { error: 'no recorded draft for this question' }, draftedBy: 'recorded Claude run' } }));
` });
link(modeSwitch, useRecorded, 0);
const buildReq = node('Build Claude request', 'n8n-nodes-base.code', 2, [1200, 440], { jsCode: code(`
// Only approved, in-date entries are sent to the model.
return $input.all().map(({ json }) => ({ json: { ...json, request: buildDraftRequest(json.row.question, json.given, json.config) } }));
`) });
link(modeSwitch, buildReq, 1);
const claude = node('Claude: draft from approved entries', 'n8n-nodes-base.httpRequest', 4.2, [1420, 440], {
  method: 'POST',
  url: 'https://api.anthropic.com/v1/messages',
  authentication: 'genericCredentialType',
  genericAuthType: 'httpHeaderAuth',
  sendHeaders: true,
  headerParameters: { parameters: [{ name: 'anthropic-version', value: '2026-10-21' }, { name: 'content-type', value: 'application/json' }] },
  sendBody: true,
  specifyBody: 'json',
  jsonBody: '={{ JSON.stringify($json.request) }}',
  options: { response: { response: { neverError: true } } },
}, { onError: 'continueRegularOutput' });
link(buildReq, claude);
const parse = node('Parse the draft (fail safe)', 'n8n-nodes-base.code', 2, [1640, 440], { jsCode: code(`
const sent = $('Build Claude request').all();
return $input.all().map((item, i) => ({ json: { ...sent[i].json, request: undefined, draft: parseDraftResponse(item.json), draftedBy: 'Claude' } }));
`) });
link(claude, parse);
const check = node('Check the draft against the library', 'n8n-nodes-base.code', 2, [1860, 320], { jsCode: code(`
return $input.all().map(({ json }) => {
  const fails = verify(json.draft, json.hits, json.row.question, json.today);
  const base = { id: json.row.id, section: json.row.section, question: json.row.question, hits: json.hits.map((h) => ({ id: h.id, score: h.score })), draft: json.draft, config: json.config };
  const audit = [auditEntry(new Date().toISOString(), json.row.id, 'model', 'drafted', json.draftedBy + ': ' + ((json.draft && json.draft.citations) || []).map((c) => c.entry_id).join(', '))];
  if (fails.length) {
    const owner = json.hits[0].entry.owner;
    audit.push(auditEntry(new Date().toISOString(), json.row.id, 'checks', 'failed', fails.map((f) => f.code).join(', ')));
    return { json: { ...base, route: 'owner', reasons: fails, owner, checks: fails, audit } };
  }
  const sources = [...new Set(json.draft.citations.map((c) => c.entry_id))];
  const nda = json.given.some((h) => sources.includes(h.id) && h.entry.evidence && h.entry.evidence.share === 'nda');
  audit.push(auditEntry(new Date().toISOString(), json.row.id, 'checks', 'passed', 'every check passed against ' + sources.join(', ')));
  return { json: { ...base, route: 'ready', reasons: nda ? [{ code: 'EVIDENCE_UNDER_NDA' }] : [], owner: null, checks: [], sources, buyer: buyerAnswer(json.draft, json.hits, json.row.question, json.today), audit } };
});
`) });
link(useRecorded, check);
link(parse, check);
const ready = node('Ready or owner?', 'n8n-nodes-base.switch', 3.2, [2080, 320], { mode: 'expression', numberOutputs: 2, output: "={{ $json.route === 'ready' ? 0 : 1 }}" });
link(check, ready);

// ---------- 3. Owners ----------
const owners = node('Everything for an owner', 'n8n-nodes-base.merge', 3, [2300, 200], { numberInputs: 2 });
link(toOwner, owners, 0, 0);
link(ready, owners, 1, 1);
const tokens = node('Add options and a token', 'n8n-nodes-base.code', 2, [2520, 200], { jsCode: code(`
// n8n signs each resume URL with the instance secret. On top of that, each question gets a random token, so a
// decision cannot be replayed onto another question. Start n8n with NODE_FUNCTION_ALLOW_BUILTIN=crypto.
let rand = null;
try { rand = require('crypto').randomBytes; } catch (e) { rand = null; }
const token = () => (rand ? rand(16).toString('hex') : globalThis.crypto && globalThis.crypto.randomUUID ? globalThis.crypto.randomUUID() : Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2));
return $input.all().map(({ json }) => ({ json: { ...json, options: optionsFor(json), approvalToken: token(), tokenSource: rand ? 'crypto.randomBytes' : 'fallback' } }));
`) });
link(owners, tokens);
const approvalMode = node('Queue or wait?', 'n8n-nodes-base.switch', 3.2, [2740, 200], { mode: 'expression', numberOutputs: 2, output: "={{ $json.config.approvalMode === 'wait' ? 1 : 0 }}" });
link(tokens, approvalMode);
const queue = node('Owner queue (nothing sent)', 'n8n-nodes-base.code', 2, [2980, 100], { jsCode: `return $input.all().map(({ json }) => ({ json: { ...json, approvalToken: undefined } }));
` });
link(approvalMode, queue, 0);
const loop = node('One question at a time', 'n8n-nodes-base.splitInBatches', 3, [2980, 360], { batchSize: 1, options: {} });
link(approvalMode, loop, 1);
const notify = node('Ask the owner', 'n8n-nodes-base.httpRequest', 4.2, [3220, 460], {
  method: 'POST',
  url: '={{ $json.config.notifyUrl }}',
  sendBody: true,
  specifyBody: 'json',
  jsonBody: '={{ JSON.stringify({ id: $json.id, question: $json.question, owner: $json.owner, reasons: $json.reasons, draft: $json.draft, options: $json.options, approvalToken: $json.approvalToken, tokenSource: $json.tokenSource, resumeUrl: $execution.resumeUrl }) }}',
  options: {},
});
link(loop, notify, 1);
// The resume URL is signed by n8n and each question carries its own random token. It accepts POST only, so a
// link previewer's GET cannot resume it, and a question nobody answers in three days resumes empty and stays
// "waiting". (Header auth on the resume call refused even the correct key in the n8n 2.46.4 test.)
const wait = node('Wait for the owner', 'n8n-nodes-base.wait', 1.1, [3440, 460], { resume: 'webhook', httpMethod: 'POST', limitWaitTime: true, limitType: 'afterTimeInterval', resumeAmount: 3, resumeUnit: 'days', options: {} },
  { webhookId: 'e4b2d3c5-6f7a-4b8c-9d0e-1f2a3b4c5d6e' });
link(notify, wait);
const record = node("Record the owner's decision", 'n8n-nodes-base.code', 2, [3660, 460], { jsCode: `// The owner's decision arrives as the Wait node's webhook body: { token, decision, answer, by }.
// It counts only if the token matches and the decision is one of the options offered for this question.
// It is recorded against the owner the link was sent to; a name in the body is kept only as "signed as".
const item = $('One question at a time').first().json;
const body = $json.body || {};
const tokenOk = !!item.approvalToken && body.token === item.approvalToken;
const option = (item.options || []).find((o) => o.id === body.decision);
const text = typeof body.answer === 'string' ? body.answer.trim().slice(0, 1500) : '';
let decision = null, finalAnswer = '';
const signedAs = typeof body.by === 'string' ? body.by.slice(0, 80) : '';
if (!tokenOk) decision = { status: 'Waiting for ' + item.owner + ' (a decision without the right token was ignored)', by: 'unverified caller' };
else if (!option || (option.id === 'answer' && !text)) decision = { status: 'Waiting for ' + item.owner + ' (decision not valid for this question)', by: item.owner };
else if (option.id === 'use_draft') { decision = { status: 'Approved by ' + item.owner, by: item.owner }; finalAnswer = item.draft.answer; }
else if (option.id === 'answer') { decision = { status: 'Answered by ' + item.owner + '; sent to the library owner for review', by: item.owner, toLibrary: true }; finalAnswer = text; }
else decision = { status: 'Not answered in writing: to discuss with your account team', by: item.owner };
if (tokenOk && signedAs) decision.signedAs = signedAs;
return [{ json: { ...item, approvalToken: undefined, decision, finalAnswer, audit: [...item.audit, { at: new Date().toISOString(), id: item.id, actor: decision.by, step: 'owner decision', detail: (tokenOk && option ? option.label : 'ignored') + (decision.signedAs ? ' (signed as ' + decision.signedAs + ')' : '') }] } }];
` });
link(wait, record);
link(record, loop);

// ---------- 4. Answered questionnaire and audit ----------
const all = node('All questions', 'n8n-nodes-base.merge', 3, [3920, 220], { numberInputs: 3 });
link(ready, all, 0, 0);
link(queue, all, 0, 1);
link(loop, all, 0, 2);
const out = node('Answered questionnaire and audit log', 'n8n-nodes-base.code', 2, [4160, 220], { jsCode: code(`
const results = $input.all().map((i) => i.json).sort((a, b) => a.id.localeCompare(b.id, undefined, { numeric: true }));
const rows = results.map(finalRow);
const audit = results.flatMap((r) => r.audit || []);
const summary = { questions: rows.length, ready: rows.filter((r) => r.status.startsWith('Ready')).length, waiting: rows.filter((r) => r.status.startsWith('Waiting')).length, byOwner: rows.filter((r) => r.owner).reduce((a, r) => ({ ...a, [r.owner]: (a[r.owner] || 0) + 1 }), {}), toLibraryReview: results.filter((r) => r.decision && r.decision.toLibrary).map((r) => r.id) };
return [{ json: { summary, rows, audit } }];
`) });
link(all, out);
const reportSwitch = node('Send the report?', 'n8n-nodes-base.switch', 3.2, [4400, 220], { mode: 'expression', numberOutputs: 2, output: "={{ $('Config').first().json.config.reportUrl ? 1 : 0 }}" });
link(out, reportSwitch);
const send = node('Send the report', 'n8n-nodes-base.httpRequest', 4.2, [4640, 320], { method: 'POST', url: "={{ $('Config').first().json.config.reportUrl }}", sendBody: true, specifyBody: 'json', jsonBody: '={{ JSON.stringify($json) }}', options: {} });
link(reportSwitch, send, 1);
sticky('Note: audit', [3880, -260], 760, 120, '### 4. Answered questionnaire and audit log\nEvery row says where its answer came from (entry and owner) or who it waits for. Owner-written answers go to the library owner for review before reuse.', 7);

const workflow = { name: 'Security questionnaire desk (synthetic, fictional vendor)', nodes, connections, pinData: {}, settings: { executionOrder: 'v1' }, meta: { templateCredsSetupCompleted: true }, tags: [] };
fs.mkdirSync(here('../workflow/'), { recursive: true });
fs.writeFileSync(here('../workflow/questionnaire-desk.n8n.json'), JSON.stringify(workflow, null, 2) + '\n');
console.log('workflow written:', nodes.length, 'nodes; recorded drafts embedded:', Object.keys(recorded).length);
