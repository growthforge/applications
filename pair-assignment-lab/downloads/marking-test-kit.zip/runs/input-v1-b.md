===== JOB S9 =====
You are marking a learner's submission for an AI masterclass assignment. The learner used Claude to analyse a spreadsheet from their role, was asked to check Claude's analysis themselves, and to recommend a next step.

Mark the submission against this rubric. Use the level descriptors to choose a score for each criterion.

Analysis and insight (id "insight", 0 to 3):
  0: No insight, or only Claude's output pasted with no question or reading of it.
  1: A general description of the data with no figure or no link to a question.
  2: A specific insight with a figure, but not tied to the question the learner set out to answer.
  3: A specific insight, backed by the right figure, that answers the learner's own question and says why it happened.

Checking Claude's analysis (id "verification", 0 to 2, must be at least 1 to pass):
  0: No check, or only a claim of checking with no check named.
  1: A specific check is named but its result is missing, or the only check was asking Claude to re-check itself.
  2: A specific, independent check with its result, and what the learner kept or changed because of it.

Next step (id "nextStep", 0 to 2):
  0: No next step.
  1: A next step that is vague, not owned, or does not follow from the insight.
  2: A concrete action with an owner or a date that follows from the insight.

Chart or table (id "visual", 0 to 2):
  0: No chart or table.
  1: A chart or table that is present but does not show the insight, or is unlabelled.
  2: A labelled chart or table that shows the insight at a glance.

Prompt and data note (id "evidence", 0 to 1):
  0: The prompt used is missing, or there is no note on the data.
  1: The prompt used is included, with one limitation of the data.

Rules:
- The pass mark is 6 out of 10, and a submission must score at least 1 on "Checking Claude's analysis" to pass.
- Give feedback with one strength and one next step for the learner.

Return only JSON in this shape:
{"scores": {"insight": 0, "verification": 0, "nextStep": 0, "visual": 0, "evidence": 0}, "total": 0, "passed": false, "feedback": {"strength": "", "next_step": ""}}

Submission:
Question: Is Operations overspending this quarter?

Prompt: "Here are our Q3 expenses. Is any team overspending? Show each team's monthly totals."

Insight: Sales is the team to watch: its spend went from £6,600 in July to £12,790 in September, almost all of it trade-show travel and hotels.

Check: I filtered the sheet to Sales in September and summed it myself: £12,790, the same as Claude. I kept the figure.

Next step: Sales lead to confirm by 14 November whether the trade show was budgeted.

Chart: labelled column chart of Sales spend by month, July to September.

Limitation: no budget figures in the data, so "overspending" can only mean "spending more than before".

===== END JOB S9 =====

===== JOB S10 =====
You are marking a learner's submission for an AI masterclass assignment. The learner used Claude to analyse a spreadsheet from their role, was asked to check Claude's analysis themselves, and to recommend a next step.

Mark the submission against this rubric. Use the level descriptors to choose a score for each criterion.

Analysis and insight (id "insight", 0 to 3):
  0: No insight, or only Claude's output pasted with no question or reading of it.
  1: A general description of the data with no figure or no link to a question.
  2: A specific insight with a figure, but not tied to the question the learner set out to answer.
  3: A specific insight, backed by the right figure, that answers the learner's own question and says why it happened.

Checking Claude's analysis (id "verification", 0 to 2, must be at least 1 to pass):
  0: No check, or only a claim of checking with no check named.
  1: A specific check is named but its result is missing, or the only check was asking Claude to re-check itself.
  2: A specific, independent check with its result, and what the learner kept or changed because of it.

Next step (id "nextStep", 0 to 2):
  0: No next step.
  1: A next step that is vague, not owned, or does not follow from the insight.
  2: A concrete action with an owner or a date that follows from the insight.

Chart or table (id "visual", 0 to 2):
  0: No chart or table.
  1: A chart or table that is present but does not show the insight, or is unlabelled.
  2: A labelled chart or table that shows the insight at a glance.

Prompt and data note (id "evidence", 0 to 1):
  0: The prompt used is missing, or there is no note on the data.
  1: The prompt used is included, with one limitation of the data.

Rules:
- The pass mark is 6 out of 10, and a submission must score at least 1 on "Checking Claude's analysis" to pass.
- Give feedback with one strength and one next step for the learner.

Return only JSON in this shape:
{"scores": {"insight": 0, "verification": 0, "nextStep": 0, "visual": 0, "evidence": 0}, "total": 0, "passed": false, "feedback": {"strength": "", "next_step": ""}}

Submission:
Question: Which team's spending changed most in Q3, and why?

Prompt: "Which team's spending changed most from July to September, and what drove it? Use the notes column."

Insight: Sales, up from £6,600 in July to £12,790 in September, driven by the Birmingham trade show, which is a one-off.

Check: I opened a new Claude chat, uploaded the same file and asked the same question. It gave the same answer, so I'm confident in it.

Next step: I'll raise it at the next team meeting.

Chart: labelled line chart of Sales spend by month with the trade show marked.

Limitation: one quarter of data only.

===== END JOB S10 =====

===== JOB S11 =====
You are marking a learner's submission for an AI masterclass assignment. The learner used Claude to analyse a spreadsheet from their role, was asked to check Claude's analysis themselves, and to recommend a next step.

Mark the submission against this rubric. Use the level descriptors to choose a score for each criterion.

Analysis and insight (id "insight", 0 to 3):
  0: No insight, or only Claude's output pasted with no question or reading of it.
  1: A general description of the data with no figure or no link to a question.
  2: A specific insight with a figure, but not tied to the question the learner set out to answer.
  3: A specific insight, backed by the right figure, that answers the learner's own question and says why it happened.

Checking Claude's analysis (id "verification", 0 to 2, must be at least 1 to pass):
  0: No check, or only a claim of checking with no check named.
  1: A specific check is named but its result is missing, or the only check was asking Claude to re-check itself.
  2: A specific, independent check with its result, and what the learner kept or changed because of it.

Next step (id "nextStep", 0 to 2):
  0: No next step.
  1: A next step that is vague, not owned, or does not follow from the insight.
  2: A concrete action with an owner or a date that follows from the insight.

Chart or table (id "visual", 0 to 2):
  0: No chart or table.
  1: A chart or table that is present but does not show the insight, or is unlabelled.
  2: A labelled chart or table that shows the insight at a glance.

Prompt and data note (id "evidence", 0 to 1):
  0: The prompt used is missing, or there is no note on the data.
  1: The prompt used is included, with one limitation of the data.

Rules:
- The pass mark is 6 out of 10, and a submission must score at least 1 on "Checking Claude's analysis" to pass.
- Give feedback with one strength and one next step for the learner.

Return only JSON in this shape:
{"scores": {"insight": 0, "verification": 0, "nextStep": 0, "visual": 0, "evidence": 0}, "total": 0, "passed": false, "feedback": {"strength": "", "next_step": ""}}

Submission:
Question: What drove the jump in Sales spending in September?

Prompt: "Explain the change in Sales spending from July to September by category, using the notes column."

Insight: Sales travel more than doubled, from £3,200 in July to £9,300 in September, because of the Birmingham trade show.

Check: I added up the whole quarter in Excel and got £73,360, which matches Claude's total, so the analysis is right.

Next step: Sales lead to move trade-show costs to the events budget from Q4, agreed by 14 November.

Chart: labelled line chart of Sales travel by month.

Limitation: one quarter only.

===== END JOB S11 =====

===== JOB S12 =====
You are marking a learner's submission for an AI masterclass assignment. The learner used Claude to analyse a spreadsheet from their role, was asked to check Claude's analysis themselves, and to recommend a next step.

Mark the submission against this rubric. Use the level descriptors to choose a score for each criterion.

Analysis and insight (id "insight", 0 to 3):
  0: No insight, or only Claude's output pasted with no question or reading of it.
  1: A general description of the data with no figure or no link to a question.
  2: A specific insight with a figure, but not tied to the question the learner set out to answer.
  3: A specific insight, backed by the right figure, that answers the learner's own question and says why it happened.

Checking Claude's analysis (id "verification", 0 to 2, must be at least 1 to pass):
  0: No check, or only a claim of checking with no check named.
  1: A specific check is named but its result is missing, or the only check was asking Claude to re-check itself.
  2: A specific, independent check with its result, and what the learner kept or changed because of it.

Next step (id "nextStep", 0 to 2):
  0: No next step.
  1: A next step that is vague, not owned, or does not follow from the insight.
  2: A concrete action with an owner or a date that follows from the insight.

Chart or table (id "visual", 0 to 2):
  0: No chart or table.
  1: A chart or table that is present but does not show the insight, or is unlabelled.
  2: A labelled chart or table that shows the insight at a glance.

Prompt and data note (id "evidence", 0 to 1):
  0: The prompt used is missing, or there is no note on the data.
  1: The prompt used is included, with one limitation of the data.

Rules:
- The pass mark is 6 out of 10, and a submission must score at least 1 on "Checking Claude's analysis" to pass.
- Give feedback with one strength and one next step for the learner.

Return only JSON in this shape:
{"scores": {"insight": 0, "verification": 0, "nextStep": 0, "visual": 0, "evidence": 0}, "total": 0, "passed": false, "feedback": {"strength": "", "next_step": ""}}

Submission:
Question: Is the September rise in spending a one-off?

Prompt: "Compare each team's spend for July, August and September and tell me which changes look like one-offs."

Insight: Yes. Most of the rise is Sales travel and hotels for the Birmingham trade show; Sales travel went from £3,200 in July to £6,820 in September.

Check: I rebuilt Sales travel for September with a filter and got £6,820. Claude had said £9,300 because it counted a £1,240 refund as spend, so I used my figure.

Next step: Finance to tag trade-show costs as events from 1 December so they are reported separately.

Chart: I would use a line chart of Sales travel by month to show this.

Limitation: no prior-year data to compare against.

===== END JOB S12 =====
