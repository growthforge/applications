## 1. Which team's spending changed most this quarter, and is it a one-off?

**Sales, by a clear margin.** Net of the September refund, Sales went from £6,600 in July, to £5,670 in August, to £12,790 in September. That is +£6,190 (about +94%) on July, and more than double August.

Monthly spend by team, in £ (credits netted off):

| Team | Jul | Aug | Sep | Jul to Sep |
|---|---|---|---|---|
| Sales | 6,600 | 5,670 | 12,790 | +6,190 (+94%) |
| Operations | 4,000 | 3,440 | 5,500 | +1,500 (+38%) |
| Technology | 5,200 | 8,070 | 5,610 | +410 (+8%) |
| Finance | 2,250 | 1,940 | 2,430 | +180 (+8%) |
| People | 1,850 | 1,600 | 2,000 | +150 (+8%) |
| Customer Service | 1,500 | 1,300 | 1,610 | +110 (+7%) |
| **Total** | **21,400** | **22,020** | **29,940** | **+8,540 (+40%)** |

Sales accounts for about 72% of the total increase between July and September.

**Is it a one-off? Probably, but the file can't confirm it.**
- The jump sits in two lines, both annotated as including Birmingham trade show costs: Travel £8,060 (against £3,200 in July and £2,750 in August) and Hotels £4,570 (against £2,100 and £1,810).
- The rest of Sales is in its normal range: Meals £970 (£900 and £770 before) and Software £430 (£400 and £340 before).
- So the spike is concentrated in a named event rather than a general rise in Sales spend. August was actually lower than July.
- Two caveats. The notes say "includes" without giving the trade show amount, so I can't tell you its exact cost. And the file can't tell me whether more shows are planned. I'd check with Sales before treating it as non-recurring in a forecast.

Other movers, so they aren't mistaken for the main story:
- **Technology** had the biggest swing in August (£8,070, +£2,870 on July). The Software line carries the note "Includes annual licence renewal". It was back to £5,610 in September, so that one has already reversed.
- **Operations** is up £1,500 on July, of which £1,180 is a single row: a site visit to the Leeds depot. That row sits at the very bottom of the file, away from the other September Operations rows. Without it, Operations was £4,320 in September (+8% on July).

## 2. What did Sales spend on travel in September?

**£6,820 net.** That is £8,060 of travel debits less a £1,240 credit (refund: cancelled rail booking).

- £8,060 is the gross spend before the refund, and it includes the Birmingham trade show travel.
- The refund row is also at the very bottom of the file, separate from the other September Sales rows.
- Amounts in the file are unsigned and the debit/credit column carries the direction. Summing the amount column would give £9,300, which is wrong by £2,480.
- The note doesn't say whether the cancelled rail booking was for the trade show, so I haven't tried to attribute it.

## Basis

The file covers July to September only, so "changed this quarter" means movement across those three months. There is no Q2 to compare against. All team totals above treat credit rows as reductions.
