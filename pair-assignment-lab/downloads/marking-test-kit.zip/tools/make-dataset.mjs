// Builds the synthetic dataset the sample assignment uses: Q3 2026 team expenses for a fictional
// company (Northgate Logistics Ltd). Deterministic, so every figure quoted in the sample submissions
// can be recomputed. Illustrative only.
import fs from 'node:fs';

const months = ['2026-07', '2026-08', '2026-09'];
const teams = ['Sales', 'Operations', 'Finance', 'People', 'Technology', 'Customer Service'];
const categories = ['Travel', 'Hotels', 'Meals', 'Software'];
// Base monthly spend per team and category (pounds).
const base = {
  Sales: [3200, 2100, 900, 400], Operations: [1800, 900, 600, 700], Finance: [300, 200, 250, 1500],
  People: [500, 300, 450, 600], Technology: [400, 300, 300, 4200], 'Customer Service': [250, 150, 300, 800],
};
// Month factors and one-off events that make the quarter worth analysing.
const factor = { '2026-07': 1.0, '2026-08': 0.86, '2026-09': 1.08 };
const rows = [];
for (const m of months) for (const t of teams) categories.forEach((c, i) => {
  let amount = Math.round(base[t][i] * factor[m] / 10) * 10;
  let note = '';
  if (m === '2026-09' && t === 'Sales' && c === 'Travel') { amount += 4600; note = 'Includes Birmingham trade show travel'; }
  if (m === '2026-09' && t === 'Sales' && c === 'Hotels') { amount += 2300; note = 'Includes Birmingham trade show hotels'; }
  if (m === '2026-08' && t === 'Technology' && c === 'Software') { amount += 3600; note = 'Includes annual licence renewal'; }
  rows.push({ month: m, team: t, category: c, amount, type: 'debit', note });
});
// The export records every amount as positive, with a credit flag on refunds. Summing the amount column
// alone counts the refund as spend: that is the trap the practice task is built around.
rows.push({ month: '2026-09', team: 'Sales', category: 'Travel', amount: 1240, type: 'credit', note: 'Refund: cancelled rail booking' });
rows.push({ month: '2026-09', team: 'Operations', category: 'Travel', amount: 1180, type: 'debit', note: 'Site visit to the Leeds depot' });

const signed = (r) => (r.type === 'credit' ? -r.amount : r.amount);
const sum = (f) => rows.filter(f).reduce((a, r) => a + signed(r), 0);
const figures = {
  total: sum(() => true),
  byMonth: Object.fromEntries(months.map((m) => [m, sum((r) => r.month === m)])),
  salesTravelSep: sum((r) => r.team === 'Sales' && r.category === 'Travel' && r.month === '2026-09'),
  salesTravelSepIfCreditIgnored: rows.filter((r) => r.team === 'Sales' && r.category === 'Travel' && r.month === '2026-09').reduce((a, r) => a + r.amount, 0),
  salesTravelJul: sum((r) => r.team === 'Sales' && r.category === 'Travel' && r.month === '2026-07'),
  salesTotalByMonth: Object.fromEntries(months.map((m) => [m, sum((r) => r.team === 'Sales' && r.month === m)])),
  techSoftwareAug: sum((r) => r.team === 'Technology' && r.category === 'Software' && r.month === '2026-08'),
  byTeam: Object.fromEntries(teams.map((t) => [t, sum((r) => r.team === t)])),
  byCategory: Object.fromEntries(categories.map((c) => [c, sum((r) => r.category === c)])),
  rows: rows.length,
};
const cell = (v) => (/[",\n]/.test(String(v)) ? '"' + String(v).replace(/"/g, '""') + '"' : String(v));
const csv = ['month,team,category,amount_gbp,type,note', ...rows.map((r) => [r.month, r.team, r.category, r.amount, r.type, r.note].map(cell).join(','))].join('\n') + '\n';
fs.mkdirSync(new URL('../data/', import.meta.url), { recursive: true });
fs.writeFileSync(new URL('../data/q3-expenses.csv', import.meta.url), csv);
fs.writeFileSync(new URL('../data/q3-expenses-figures.json', import.meta.url), JSON.stringify(figures, null, 2) + '\n');
console.log(JSON.stringify(figures, null, 1));
