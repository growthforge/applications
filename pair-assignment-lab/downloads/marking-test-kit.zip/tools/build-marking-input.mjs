// Fills the marking prompts (v1 to v2.4) with the rubric and each sample submission, exactly as a
// marking service would send them, and writes one file per prompt version for the marking runs.
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
const read = (p) => fs.readFileSync(new URL(p, import.meta.url), 'utf8');
const rubrics = { v1: JSON.parse(read('../data/rubric-v2.json')), v2: JSON.parse(read('../data/rubric-v2.json')), 'v2.1': JSON.parse(read('../data/rubric-v2.1.json')), 'v2.2': JSON.parse(read('../data/rubric-v2.2.json')), 'v2.3': JSON.parse(read('../data/rubric.json')), 'v2.4': JSON.parse(read('../data/rubric.json')) };
const answerKey = read('../data/answer-key.md').trim();
const samples = JSON.parse(read('../data/samples.json')).samples;
const schemas = { 'v2.3': read('../prompts/schema-v2.3.json').trim(), 'v2.4': read('../prompts/schema-v2.3.json').trim() };
const schemaFor = (v) => schemas[v] || read('../prompts/schema.json').trim();

// Up to v2.2 the gate line said "at least 1" whatever the rubric's gate was (the bug fixed in v2.3); the
// saved inputs for those versions are kept exactly as they were sent.
export function rubricText(r) {
  const gateLine = r.version === '2.3' ? `, the pass gate: a pass needs at least ${r.gate.min}` : ', must be at least 1 to pass';
  return r.criteria.map((c) => `${c.name} (id "${c.id}", 0 to ${c.max}${c.gate ? gateLine : ''}):\n`
    + c.levels.map((l) => `  ${l.score}: ${l.descriptor}`).join('\n')).join('\n\n');
}
export function fill(version, submission) {
  const rubric = rubrics[version];
  return read(`../prompts/marking-${version}.md`)
    .replace('{{ANSWER_KEY}}', answerKey)
    .replace('{{RUBRIC}}', rubricText(rubric))
    .replace('{{PASS_MARK}}', String(rubric.passMark))
    .replace('{{GATE_MIN}}', String(rubric.gate ? rubric.gate.min : 1))
    .replace('{{SCHEMA}}', schemaFor(version))
    .replace('{{SUBMISSION}}', submission.trim());
}
if (fileURLToPath(import.meta.url) === process.argv[1]) {
  fs.mkdirSync(new URL('../runs/', import.meta.url), { recursive: true });
  const versions = process.argv.slice(2).length ? process.argv.slice(2) : ['v2.4'];
  for (const v of versions) {
    const jobs = samples.map((s) => `===== JOB ${s.id} =====\n${fill(v, s.text)}\n===== END JOB ${s.id} =====`).join('\n\n');
    fs.writeFileSync(new URL(`../runs/input-${v}.md`, import.meta.url), jobs + '\n');
  }
  console.log('wrote', versions.map((v) => `runs/input-${v}.md`).join(', '), 'for', samples.length, 'samples');
}
