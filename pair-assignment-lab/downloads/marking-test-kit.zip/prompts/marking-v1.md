You are marking a learner's submission for an AI masterclass assignment. The learner used Claude to analyse a spreadsheet from their role, was asked to check Claude's analysis themselves, and to recommend a next step.

Mark the submission against this rubric. Use the level descriptors to choose a score for each criterion.

{{RUBRIC}}

Rules:
- The pass mark is {{PASS_MARK}} out of 10, and a submission must score at least 1 on "Checking Claude's analysis" to pass.
- Give feedback with one strength and one next step for the learner.

Return only JSON in this shape:
{"scores": {"insight": 0, "verification": 0, "nextStep": 0, "visual": 0, "evidence": 0}, "total": 0, "passed": false, "feedback": {"strength": "", "next_step": ""}}

Submission:
{{SUBMISSION}}
