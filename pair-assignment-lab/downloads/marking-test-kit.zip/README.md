# Marking test kit

Prepared by Hemanth Vallamkonda as part of an application to PAIR. Independent and illustrative. Synthetic data only.

- `node tools/build-marking-input.mjs v2.4` fills the marking prompt with the rubric, the answer key and each submission (`runs/input-v2.4.md`), exactly as the marker receives them. The saved `runs/input-*.md` files are the exact inputs each earlier version was run on (v2.1 used an answer key that also named the overstated figure; v2.2 lists correct figures only but its prompt still described the old gate of 1, fixed in v2.3; v2.4 changes only the chart sentence).
- Each run is one Claude Code session given only its input file: every job in it is the full marking prompt with one submission, and the session marks them in turn. The session saw no reference marks and no other files.
- `runs/trap-test-sonnet.md` is one try of the practice file on Claude (Sonnet, reading the file, no code). It netted the refund correctly.
- Each `runs/<prompt>-<model>-run<n>.json` holds what Claude returned for those inputs (files starting `b-` are the four hard cases, S9 to S12, run as a second batch for v1 and v2).
- `node tools/analyse-runs.mjs` compares every run with the reference marks in `data/samples.json` and writes `runs/summary.json`.
- To test another model or prompt: mark the jobs in an input file, save the JSON in the same shape, and run the analysis again.
