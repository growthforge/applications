import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { tradingCheck, spatialRisk, requirement, shortlist, checks, prepare, findHabitat } from '../src/assets/core.mjs';
import { deficitsFromRows } from '../src/assets/metric-core.mjs';

const lookups = JSON.parse(fs.readFileSync(new URL('../data/metric-lookups.json', import.meta.url)));

test('lookups come from the official metric: 133 habitats, three spatial multipliers', () => {
  assert.equal(lookups.habitats.length, 133);
  assert.deepEqual(lookups.spatial.map((s) => s.multiplier), [1, 0.75, 0.5]);
  assert.equal(findHabitat(lookups, 'Other neutral grassland').distinctiveness, 'Medium');
  assert.equal(findHabitat(lookups, 'Grassland - Lowland meadows').distinctiveness, 'V.High');
});

test('trading rules: high needs the same habitat', () => {
  assert.equal(tradingCheck(lookups, 'Lowland mixed deciduous woodland', 'Lowland mixed deciduous woodland').ok, true);
  assert.equal(tradingCheck(lookups, 'Lowland mixed deciduous woodland', 'Other woodland; broadleaved').ok, false);
  assert.equal(tradingCheck(lookups, 'Ponds (priority habitat)', 'Ponds (non-priority habitat)').ok, false);
});

test('trading rules: medium takes the same broad habitat or anything more distinctive', () => {
  assert.equal(tradingCheck(lookups, 'Other neutral grassland', 'Other neutral grassland').ok, true);
  assert.equal(tradingCheck(lookups, 'Mixed scrub', 'Hawthorn scrub').ok, true, 'same broad habitat');
  assert.equal(tradingCheck(lookups, 'Other neutral grassland', 'Ponds (priority habitat)').ok, true, 'higher distinctiveness');
  assert.equal(tradingCheck(lookups, 'Other neutral grassland', 'Mixed scrub').ok, false, 'different broad habitat, same band');
  assert.equal(tradingCheck(lookups, 'Other neutral grassland', 'Modified grassland').ok, false, 'lower band');
});

test('trading rules: low takes the same band or better; unknown habitats are refused, not guessed', () => {
  assert.equal(tradingCheck(lookups, 'Modified grassland', 'Mixed scrub').ok, true);
  assert.equal(tradingCheck(lookups, 'Modified grassland', 'Not a habitat').ok, false);
});

test("spatial risk: 1 inside the bank's LPA or NCA, 0.75 for a neighbour its page lists, else 0.5", () => {
  const bank = { lpa: 'Darlington Borough Council', nca: 'Tees Lowlands', neighbouringLpas: ['Stockton-on-Tees Borough Council'], neighbouringNcas: ['Vale of Mowbray'] };
  assert.equal(spatialRisk({ lpa: 'Darlington Borough Council', nca: '' }, bank).multiplier, 1);
  assert.equal(spatialRisk({ lpa: 'Somewhere Else', nca: 'Tees Lowlands' }, bank).multiplier, 1);
  assert.equal(spatialRisk({ lpa: 'Stockton-on-Tees Borough Council', nca: '' }, bank).multiplier, 0.75);
  assert.equal(spatialRisk({ lpa: 'Somewhere Else', nca: 'Vale of Mowbray' }, bank).multiplier, 0.75);
  const far = spatialRisk({ lpa: 'Somewhere Else', nca: 'Elsewhere' }, bank);
  assert.equal(far.multiplier, 0.5);
  assert.equal(far.tier, 'beyond');
  const unknown = spatialRisk({ lpa: 'Somewhere Else', nca: 'Elsewhere' }, { lpa: 'X', nca: 'Y' });
  assert.equal(unknown.tier, 'unconfirmed');
});

test('requirement: shortfall against the metric target, deficits as positive units', () => {
  const r = requirement({ site: { lpa: 'X', target: 0.1 }, headline: { Habitat: { baseline: 10, post: 8 } }, deficits: [{ label: 'Grassland - Other neutral grassland', band: 'Medium', units: -2.5 }] });
  assert.equal(r.types.Habitat.target, 11);
  assert.equal(r.types.Habitat.shortfall, 3);
  assert.equal(r.deficits[0].units, 2.5);
});

test('shortlist: only trading-rule matches, best spatial multiplier first, units grossed up by the multiplier', () => {
  const banks = [
    { name: 'Far Bank', status: 'live', lpa: 'Far', nca: 'Far NCA', habitats: ['Other neutral grassland'] },
    { name: 'Near Bank', status: 'live', lpa: 'Home', nca: 'Home NCA', habitats: ['Other neutral grassland'] },
    { name: 'Wrong Habitat', status: 'live', lpa: 'Home', nca: 'Home NCA', habitats: ['Mixed scrub'] },
    { name: 'Upcoming', status: 'upcoming', lpa: 'Home', nca: 'Home NCA', habitats: ['Other neutral grassland'] },
  ];
  const req = requirement({ site: { lpa: 'Home', nca: '' }, headline: {}, deficits: [{ label: 'Grassland - Other neutral grassland', band: 'Medium', units: -2 }] });
  const [s] = shortlist(lookups, req, banks);
  assert.deepEqual(s.options.map((o) => o.bank), ['Near Bank'], 'banks beyond the neighbours are listed only when nothing closer qualifies');
  assert.equal(s.more, 1);
  assert.equal(s.options[0].unitsToSource, 2);
  const [far] = shortlist(lookups, req, banks.filter((b) => b.name === 'Far Bank'));
  assert.equal(far.best.unitsToSource, 2, 'trading rules come before spatial risk: like for like at face value');
  assert.equal(far.best.countsAs, 1);
  assert.equal(far.best.topUp, 1);
});

test('a bank shows the lowest distinctiveness habitat that satisfies the rule, not the first by name', () => {
  const req = requirement({ site: { lpa: 'Home', nca: '' }, headline: {}, deficits: [{ label: 'Woodland and forest - Other woodland; broadleaved', band: 'Medium', units: -1 }] });
  const [s] = shortlist(lookups, req, [{ name: 'B', status: 'live', lpa: 'Home', nca: 'N', habitats: ['Lowland meadows', 'Ponds (priority habitat)', 'Other neutral grassland'] }]);
  assert.equal(s.best.offered, 'Ponds (priority habitat)');
});

test('checks: very high losses stop the standard quote; no match says so; drafts say they are drafts', () => {
  const req = requirement({ site: { lpa: 'Home' }, headline: {}, deficits: [{ label: 'Grassland - Lowland meadows', band: 'V.High', units: -1 }] });
  const ck = checks(req, shortlist(lookups, req, []));
  assert.ok(ck.some((c) => c.level === 'stop' && /bespoke/.test(c.text)));
  assert.ok(ck.some((c) => c.level === 'stop' && /No listed bank/.test(c.text)));
  assert.ok(ck.some((c) => /Draft only/.test(c.text)));
});

test('prepare: brief carries the requirement, the shortlist and the checks', () => {
  const out = prepare(lookups, { site: { lpa: 'Home', nca: 'Home NCA', name: 'Test site' }, headline: { Habitat: { baseline: 5, post: 4 } }, deficits: [{ label: 'Grassland - Other neutral grassland', band: 'Medium', units: -1.2 }] },
    [{ name: 'Near Bank', status: 'live', lpa: 'Home', nca: 'Home NCA', habitats: ['Other neutral grassland'] }]);
  assert.match(out.brief, /Near Bank/);
  assert.match(out.brief, /Draft only/);
  assert.match(out.brief, /shortfall 1.5/);
});

test('trading cascade: surplus gains in a higher band meet lower-band losses, never the reverse', () => {
  const pond = { label: 'Lakes - Ponds (priority habitat)', group: 'Lakes', band: 'High' };
  const grass = { label: 'Grassland - Other neutral grassland', group: 'Grassland', band: 'Medium' };
  const modified = { label: 'Grassland - Modified grassland', group: 'Grassland', band: 'Low' };
  assert.deepEqual(deficitsFromRows([{ ...grass, units: -1.5 }, { ...pond, units: 2 }]), [], 'a high gain meets a medium loss');
  assert.deepEqual(deficitsFromRows([{ ...grass, units: -1.5 }, { ...pond, units: 1 }]).map((d) => d.units), [-0.5]);
  assert.deepEqual(deficitsFromRows([{ ...pond, units: -1 }, { ...grass, units: 3 }]).map((d) => [d.band, d.units]), [['High', -1]], 'a medium gain never meets a high loss');
  assert.deepEqual(deficitsFromRows([{ ...modified, units: -1 }, { ...grass, units: 0.4 }]).map((d) => [d.band, d.units]), [['Low', -0.6]]);
});

test('like for like before a trade-up to a different, more distinctive habitat; stops are listed first', () => {
  const req = requirement({ site: { lpa: 'Home', nca: 'Home NCA' }, headline: { Habitat: { baseline: 5, post: 4 } }, deficits: [{ label: 'Heathland and shrub - Mixed scrub', band: 'Medium', units: -1 }] });
  const list = shortlist(lookups, req, [
    { name: 'Ponds Here', status: 'live', lpa: 'Home', nca: 'Home NCA', habitats: ['Ponds (priority habitat)'] },
    { name: 'Scrub Next Door', status: 'live', lpa: 'Next', nca: 'Next NCA', neighbouringLpas: ['Home'], habitats: ['Mixed scrub'] },
  ]);
  assert.deepEqual(list[0].options.map((o) => o.bank), ['Scrub Next Door', 'Ponds Here']);
  assert.equal(list[0].options[1].tradeUp, true);
  const ck = checks(requirement({ site: { lpa: 'Home', nca: '' }, headline: {}, deficits: [{ label: 'Grassland - Lowland meadows', band: 'V.High', units: -1 }] }), []);
  assert.equal(ck[0].level, 'stop');
});
