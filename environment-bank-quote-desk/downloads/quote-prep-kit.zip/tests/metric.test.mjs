// The two workbook readers (exceljs for the MCP server, xlsx-lite for the page) on six workbooks made from the
// official v1.1.0 template, checked against each other, against the page's scenario path, and against the
// outcomes worked out by hand before any run (eval/expected.json). Writes eval/reader-run.json.
// Needs tests/metrics/*.xlsx: node tools/make-test-metrics.mjs <official v1.1.0 macro-disabled workbook>
// Run from the deliverable folder: node --test tests/
import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import zlib from 'node:zlib';
import { fileURLToPath } from 'node:url';
import { readMetric } from '../mcp/metric.mjs';
import { openXlsx } from '../src/assets/xlsx-lite.mjs';
import { readMetricFrom, scenarioToMetric, SHEETS } from '../src/assets/metric-core.mjs';
import { prepare } from '../src/assets/core.mjs';

const root = fileURLToPath(new URL('..', import.meta.url));
const load = (f) => JSON.parse(fs.readFileSync(root + f, 'utf8'));
const lookups = load('data/metric-lookups.json');
const banks = load('data/habitat-banks.json').banks;
const scenarios = load('data/scenarios.json').scenarios;
const expected = load('eval/expected.json').cases;
const dir = root + 'tests/metrics/';
const inflate = async (b) => zlib.inflateRawSync(b);

async function lite(file, siteNca) {
  const book = await openXlsx(fs.readFileSync(dir + file), { inflate });
  await book.loadSheets(Object.values(SHEETS));
  return readMetricFrom(book, { siteNca, file });
}

function outcome(metric) {
  const out = prepare(lookups, metric, banks);
  return {
    deficits: out.requirement.deficits.map((d) => {
      const s = out.shortlist.find((x) => x.deficit.label === d.label);
      return { label: d.label, band: d.band, units: d.units, best: s.best?.bank ?? null, multiplier: s.best?.spatial.multiplier ?? null, unitsToSource: s.best?.unitsToSource ?? null };
    }),
    shortfall: Object.fromEntries(Object.entries(out.requirement.types).map(([k, t]) => [k, t.shortfall])),
    stops: out.checks.filter((c) => c.level === 'stop').length,
    checks: out.checks.map((c) => c.text),
    brief: out.brief,
  };
}

test('both readers agree with the page and with the hand-worked outcomes on all six workbooks', async () => {
  const run = { ranAt: new Date().toISOString(), node: process.version, template: 'Statutory Biodiversity Metric 1.1.0 (macro-disabled)', cases: [] };
  for (const e of expected) {
    const s = scenarios.find((x) => x.file === e.file);
    const viaExcel = await readMetric(dir + e.file, { siteNca: e.site_nca });
    const viaLite = await lite(e.file, e.site_nca);
    const viaPage = scenarioToMetric(lookups, { ...s, nca: e.site_nca });
    for (const m of [viaExcel, viaLite]) {
      assert.equal(m.version, '1.1.0');
      assert.deepEqual(m.site, viaPage.site, e.file + ': site');
      assert.deepEqual(m.headline, Object.fromEntries(Object.entries(viaPage.headline).filter(([, h]) => h.baseline > 0 || h.post > 0)), e.file + ': headline');
      assert.deepEqual(m.deficits, viaPage.deficits, e.file + ': deficits');
      const json = JSON.stringify(m);
      assert.ok(!json.includes('Example Developer') && !json.includes('A. Ecologist'), 'applicant and author are never read');
    }
    const got = outcome(viaLite);
    const problems = [];
    for (const d of e.deficits) {
      const g = got.deficits.find((x) => x.label === d.label);
      if (!g) { problems.push('missing deficit ' + d.label); continue; }
      for (const k of ['band', 'units', 'best', 'multiplier', 'unitsToSource']) if (g[k] !== d[k]) problems.push(`${d.label} ${k}: ${g[k]} vs ${d[k]}`);
    }
    if (got.deficits.length !== e.deficits.length) problems.push(`deficits ${got.deficits.length} vs ${e.deficits.length}`);
    for (const [k, v] of Object.entries(e.shortfall)) if (got.shortfall[k] !== v) problems.push(`${k} shortfall ${got.shortfall[k]} vs ${v}`);
    if (got.stops !== e.stops) problems.push(`stops ${got.stops} vs ${e.stops}`);
    for (const m of e.mustCheck) if (!got.checks.some((c) => c.includes(m))) problems.push('missing check: ' + m);
    if (!got.brief.includes('Draft only')) problems.push('brief does not say draft');
    run.cases.push({ file: e.file, ok: problems.length === 0, problems, deficits: got.deficits, shortfall: got.shortfall, stops: got.stops });
  }
  fs.writeFileSync(root + 'eval/reader-run.json', JSON.stringify(run, null, 2) + '\n');
  for (const c of run.cases) assert.ok(c.ok, c.file + ': ' + c.problems.join('; '));
});

test('a workbook with a different layout is refused, not misread', async () => {
  const book = await openXlsx(fs.readFileSync(dir + expected[0].file), { inflate });
  await book.loadSheets(Object.values(SHEETS));
  const moved = { ...book, get: (n, r) => (n === 'Start' && r === 'D11' ? 'Something else' : book.get(n, r)) };
  assert.throws(() => readMetricFrom(moved), /Unexpected layout: Start!D11/);
  const older = { ...book, get: (n, r) => (n === 'Version History' && /^B/.test(r) && String(book.get(n, r) || '').startsWith('Version 1.1.0') ? 'Version 1.0.4' : book.get(n, r)) };
  assert.throws(() => readMetricFrom(older), /pinned to 1\.1\.0/);
  const notMetric = { has: () => false, get: () => null, maxRow: () => 0 };
  assert.throws(() => readMetricFrom(notMetric), /Not a Statutory Biodiversity Metric/);
});

test('a file that is not a workbook is refused', async () => {
  await assert.rejects(openXlsx(new TextEncoder().encode('not a zip at all, just text'), { inflate }), /not an \.xlsx/);
});
