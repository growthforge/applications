# BNG quote-prep kit

Prepared by Hemanth Vallamkonda as part of an application to Environment Bank. Independent and illustrative; not an Environment Bank tool. The six development sites are synthetic. Metric rules: Statutory Biodiversity Metric 1.1.0, GOV.UK, Open Government Licence v3.0. Bank details: the public listing on environmentbank.com, 3 November 2026.

## What is here
- `src/assets/core.mjs`: the rules (trading rules, spatial risk, shortfall, shortlist, checks, brief). The page and the server run this same file.
- `src/assets/metric-core.mjs`: reads a completed metric 1.1.0 by checking the label beside every cell it reads; never reads the applicant or author fields.
- `src/assets/xlsx-lite.mjs`: the browser workbook reader (no library, no upload).
- `mcp/`: the MCP server (`server.mjs`, six read-only tools, folder guard, audit log) and its exceljs reader.
- `skill/bng-quote-prep/SKILL.md`: the Claude skill. Copy the folder to `~/.claude/skills/` (personal) or `.claude/skills/` in a project.
- `data/`: the lookups extracted from the official workbook, the bank list, the synthetic sites. `eval/`: outcomes worked out by hand, and the last reader run.

## Run it
1. `cd mcp && npm install` (Node 20 or later).
2. Download the official macro-disabled metric 1.1.0 from GOV.UK and run `node tools/make-test-metrics.mjs <that file>` from the kit folder. It writes six synthetic completed metrics to `tests/metrics/`.
3. `node --test tests/core.test.mjs tests/metric.test.mjs` from the kit folder.
4. Connect the server. Claude Desktop: add to `claude_desktop_config.json` under `mcpServers`: `"bng-quote-prep": { "command": "node", "args": ["<kit>/mcp/server.mjs"], "env": { "BNG_METRIC_DIR": "<folder of metrics>" } }`. Claude Code: `claude mcp add --env BNG_METRIC_DIR=<folder> bng-quote-prep -- node <kit>/mcp/server.mjs`.
5. The end-to-end test (`cd mcp && node --test integration.test.mjs`) starts the server with the official MCP client over stdio. It is written but was not run when this kit was built.

## What it never does
Price, reserve or allocate units; claim availability; add unit types together; decide a bespoke case; read outside its folder.
