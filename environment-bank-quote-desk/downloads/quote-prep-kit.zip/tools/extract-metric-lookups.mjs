// Extracts the habitat lookups the tool needs from the official Statutory Biodiversity Metric workbook
// (version 1.1.0, macro-disabled .xlsx from GOV.UK). Contains public sector information licensed under the
// Open Government Licence v3.0. Usage: node tools/extract-metric-lookups.mjs <metric.xlsx>
import fs from 'node:fs';
import { createRequire } from 'node:module';
const require = createRequire(new URL('../mcp/package.json', import.meta.url));
const ExcelJS = require('exceljs');
const file = process.argv[2];
const wb = new ExcelJS.Workbook();
await wb.xlsx.readFile(file);
const text = (v) => (v && typeof v === 'object' ? (v.result ?? v.richText?.map((x) => x.text).join('') ?? '') : v ?? '');
const ws = wb.getWorksheet('G-1 All Habitats');
const habitats = [];
ws.eachRow((row, r) => {
  if (r < 3) return;
  const label = String(text(row.getCell('B').value)).trim();
  const band = String(text(row.getCell('K').value)).trim();
  if (!label || !band || !label.includes(' - ')) return;
  habitats.push({
    label, broad: label.split(' - ')[0].trim(), habitat: label.split(' - ').slice(1).join(' - ').trim(),
    distinctiveness: band, score: Number(text(row.getCell('L').value)), tradingRule: String(text(row.getCell('M').value)).trim(),
  });
});
const bands = [];
for (let r = 3; r <= 9; r++) {
  const b = String(text(ws.getCell('V' + r).value)).trim();
  if (b) bands.push({ band: b, score: Number(text(ws.getCell('W' + r).value)), rule: String(text(ws.getCell('X' + r).value)).trim() });
}
const g3 = wb.getWorksheet('G-3 Multipliers');
const spatial = [4, 5, 6].map((r) => ({ category: String(text(g3.getCell('S' + r).value)).trim(), multiplier: Number(text(g3.getCell('T' + r).value)) }));
const out = { source: 'The Statutory Biodiversity Metric, version 1.1.0 (GOV.UK, macro-disabled workbook). Contains public sector information licensed under the Open Government Licence v3.0.', extractedOn: new Date().toISOString().slice(0, 10), bands, spatial, habitats };
fs.writeFileSync(new URL('../data/metric-lookups.json', import.meta.url), JSON.stringify(out, null, 2) + '\n');
console.log('habitats', habitats.length, 'bands', bands.map((b) => b.band + '=' + b.score).join(', '));
console.log(JSON.stringify(spatial));
console.log(habitats.filter((h) => /meadow|neutral|scrub|broadleaved|mixed deciduous|pond|modified/i.test(h.habitat)).map((h) => `${h.label} | ${h.distinctiveness} ${h.score}`).join('\n'));
