// Turns the public habitat bank listing (captured from environmentbank.com's BNG network pages on
// 3 Nov 2026) into the bank list the tool reads. Public listing data only: no prices or unit quantities,
// which Environment Bank does not publish. Usage: node tools/build-bank-list.mjs <captured.json>
import fs from 'node:fs';
const raw = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
const names = (xs) => (xs || []).map((x) => (typeof x === 'string' ? x : x.name)).filter(Boolean);
const banks = raw.filter((b) => !b.kind || b.kind === 'bng_habitat_bank').map((b) => ({
  name: b.name,
  status: String(b.status || '').startsWith('live') ? 'live' : 'upcoming',
  county: b.county || '',
  lpa: b.lpa || '',
  nca: b.nca || '',
  register: b.biodiversity_gain_sites_register_number || null,
  habitats: b.habitat_types_on_network_listing || [],
  neighbouringLpas: names(b.neighbouring_lpas),
  neighbouringNcas: names(b.neighbouring_ncas),
  url: b.page_url || b.network_page_card_link || '',
  pageModified: b.page_last_modified || null,
}));
const out = { source: 'Environment Bank BNG network pages (public listing), captured 3 November 2026. Listing data changes; availability and prices are confirmed by an account manager.', capturedOn: '2026-11-03', banks };
fs.writeFileSync(new URL('../data/habitat-banks.json', import.meta.url), JSON.stringify(out, null, 2) + '\n');
console.log('banks', banks.length, 'live', banks.filter((b) => b.status === 'live').length, 'with neighbour lists', banks.filter((b) => b.neighbouringLpas.length).length);
