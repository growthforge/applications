// Makes synthetic "completed" metric workbooks for testing: copies of the official Statutory Biodiversity
// Metric 1.1.0 template (GOV.UK, Open Government Licence v3.0) with synthetic results typed into the cells
// the parser reads. A real metric computes these itself; these files only test that the parser finds the
// right cells in the official layout. Usage: node tools/make-test-metrics.mjs <template.xlsx>
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
const require = createRequire(new URL('../mcp/package.json', import.meta.url));
const ExcelJS = require('exceljs');

const root = fileURLToPath(new URL('..', import.meta.url));
const template = process.argv[2];
const scenarios = JSON.parse(fs.readFileSync(path.join(root, 'data/scenarios.json'), 'utf8')).scenarios;
const outDir = path.join(root, 'tests/metrics');
fs.mkdirSync(outDir, { recursive: true });

for (const s of scenarios) {
  const wb = new ExcelJS.Workbook();
  await wb.xlsx.readFile(template);
  const start = wb.getWorksheet('Start');
  start.getCell('F11').value = s.lpa;
  start.getCell('F12').value = s.name;
  start.getCell('F14').value = s.applicationType || 'Full planning';
  start.getCell('F13').value = 'Example Developer Ltd (synthetic)';
  start.getCell('F16').value = 'A. Ecologist (synthetic)';
  start.getCell('F22').value = s.target ?? 0.1;
  const hr = wb.getWorksheet('Headline Results');
  const cells = { Habitat: ['H8', 'H12'], Hedgerow: ['H9', 'H13'], Watercourse: ['H10', 'H14'] };
  for (const [type, [b, p]] of Object.entries(cells)) {
    const h = s.headline[type] || { baseline: 0, post: 0 };
    hr.getCell(b).value = h.baseline;
    hr.getCell(p).value = h.post;
  }
  const ts = wb.getWorksheet('Trading Summary Area Habitats');
  // Clear every F column value in the trading tables, then type the scenario's unit changes.
  const rowsByLabel = {};
  for (let r = 1; r <= ts.rowCount; r++) {
    const raw = ts.getCell('B' + r).value;
    const b = raw && typeof raw === 'object' ? raw.result : raw; // labels in the medium and low tables are formulas
    if (typeof b === 'string' && b.includes(' - ')) { (rowsByLabel[b.trim()] ||= []).push(r); ts.getCell('F' + r).value = 0; }
  }
  for (const [label, units] of Object.entries(s.changes)) {
    const rows = rowsByLabel[label];
    if (!rows) throw new Error(`${s.file}: "${label}" is not a row in the trading summary`);
    for (const r of rows) ts.getCell('F' + r).value = units;
  }
  // exceljs cannot write some of the template's conditional-formatting rules (it reads them without their
  // formulae). They only colour cells, so they are dropped from the test copies; values are untouched.
  let dropped = 0;
  for (const ws of wb.worksheets) {
    const before = (ws.conditionalFormattings || []).length;
    ws.conditionalFormattings = (ws.conditionalFormattings || []).filter((cf) => (cf.rules || []).every((r) => !['expression', 'cellIs'].includes(r.type) || Array.isArray(r.formulae)));
    dropped += before - ws.conditionalFormattings.length;
  }
  await wb.xlsx.writeFile(path.join(outDir, s.file));
  console.log('wrote', s.file, '(conditional formats dropped: ' + dropped + ')');
}
