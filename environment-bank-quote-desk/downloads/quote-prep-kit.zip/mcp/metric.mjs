// Reads a completed Statutory Biodiversity Metric workbook (version 1.1.0) with exceljs, through the same
// label-checked reader the page uses (src/assets/metric-core.mjs). Applicant (Start F13) and author
// (Start F16) are never read, so no personal data leaves the workbook.
import ExcelJS from 'exceljs';
import path from 'node:path';
import { readMetricFrom } from '../src/assets/metric-core.mjs';

const val = (v) => {
  if (v === null || v === undefined) return null;
  if (typeof v !== 'object') return v;
  if (v instanceof Date) return v.toISOString();
  if ('result' in v) return v.result ?? null;
  if (v.richText) return v.richText.map((x) => x.text).join('');
  if ('error' in v) return v.error;
  return null;
};

export async function readMetric(file, { siteNca = '' } = {}) {
  const wb = new ExcelJS.Workbook();
  await wb.xlsx.readFile(file);
  const book = {
    has: (name) => !!wb.getWorksheet(name),
    get: (name, ref) => val(wb.getWorksheet(name).getCell(ref).value),
    maxRow: (name) => wb.getWorksheet(name).rowCount,
  };
  return readMetricFrom(book, { siteNca, file: path.basename(file) });
}
