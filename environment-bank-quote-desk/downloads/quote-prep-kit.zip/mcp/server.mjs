#!/usr/bin/env node
// BNG quote-prep MCP server (stdio). Illustrative: prepared by Hemanth Vallamkonda as part of an application
// to Environment Bank; independent, not an Environment Bank tool.
//
// What it does: reads a completed Statutory Biodiversity Metric workbook, works out what the development
// still needs, shortlists habitat banks from a bank list that satisfy the metric's trading rules, applies
// the spatial risk multiplier, and drafts a brief for an account manager.
// What it never does: price, reserve or allocate units, contact anyone, or read files outside BNG_METRIC_DIR.
// Every tool is read-only; every call is appended to the audit log.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { z } from 'zod';
import { readMetric } from './metric.mjs';
import { prepare, tradingCheck, findHabitat, spatialRisk } from '../src/assets/core.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const dataDir = process.env.BNG_DATA_DIR || path.join(here, '..', 'data');
const metricDir = path.resolve(process.env.BNG_METRIC_DIR || path.join(here, '..', 'tests', 'metrics'));
const auditLog = process.env.BNG_AUDIT_LOG || path.join(here, 'audit.log.jsonl');
const load = (f) => JSON.parse(fs.readFileSync(path.join(dataDir, f), 'utf8'));
const lookups = load('metric-lookups.json');
const banks = load('habitat-banks.json').banks;

function audit(tool, detail) {
  fs.appendFileSync(auditLog, JSON.stringify({ at: new Date().toISOString(), tool, ...detail }) + '\n');
}

// Only files inside BNG_METRIC_DIR, and only .xlsx, can be read.
function safeMetricPath(p) {
  const full = path.resolve(metricDir, p);
  if (!full.startsWith(metricDir + path.sep)) throw new Error('Path is outside the metric folder this server is allowed to read.');
  if (!/\.xlsx$/i.test(full)) throw new Error('Only .xlsx metric workbooks are read. Save a macro-enabled .xlsm as .xlsx first.');
  if (!fs.existsSync(full)) throw new Error('No such file in the metric folder: ' + p);
  return full;
}

const text = (obj) => ({ content: [{ type: 'text', text: typeof obj === 'string' ? obj : JSON.stringify(obj, null, 2) }] });
const fail = (e) => ({ isError: true, content: [{ type: 'text', text: String(e.message || e) }] });
const READ_ONLY = { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: false };

const server = new McpServer({ name: 'bng-quote-prep', version: '0.1.0' });

server.registerTool('list_metrics', {
  title: 'List metric workbooks',
  description: 'Lists the metric workbooks (.xlsx) this server is allowed to read.',
  inputSchema: {},
  annotations: READ_ONLY,
}, async () => {
  const files = fs.readdirSync(metricDir).filter((f) => /\.xlsx$/i.test(f)).sort();
  audit('list_metrics', { count: files.length });
  return text({ folder: path.basename(metricDir), files });
});

server.registerTool('read_metric', {
  title: 'Read a statutory biodiversity metric',
  description: 'Reads a completed Statutory Biodiversity Metric 1.1.0 workbook: planning authority, project name, headline units by type, and losses by distinctiveness from the trading summary. Applicant and author fields are not read.',
  inputSchema: { file: z.string().describe('File name inside the metric folder, for example "site-a.xlsx"'), site_nca: z.string().optional().describe('National Character Area of the development site, if known (from GIS)') },
  annotations: READ_ONLY,
}, async ({ file, site_nca }) => {
  try {
    const m = await readMetric(safeMetricPath(file), { siteNca: site_nca || '' });
    audit('read_metric', { file, deficits: m.deficits.length });
    return text(m);
  } catch (e) { audit('read_metric', { file, error: String(e.message) }); return fail(e); }
});

server.registerTool('find_habitat_banks', {
  title: 'Find habitat banks',
  description: 'Searches the habitat bank list (public listing data) by planning authority, National Character Area or habitat. Shows status and the habitats listed; it does not show prices or live unit availability.',
  inputSchema: { lpa: z.string().optional(), nca: z.string().optional(), habitat: z.string().optional().describe('A habitat name from the metric, for example "Other neutral grassland"') },
  annotations: READ_ONLY,
}, async ({ lpa, nca, habitat }) => {
  const n = (s) => String(s || '').toLowerCase();
  const out = banks.filter((b) => (!lpa || n(b.lpa).includes(n(lpa))) && (!nca || n(b.nca).includes(n(nca)))
    && (!habitat || (b.habitats || []).some((h) => n(h).includes(n(habitat)))));
  audit('find_habitat_banks', { lpa, nca, habitat, results: out.length });
  return text({ results: out.slice(0, 25), total: out.length, note: 'Public listing data; availability and prices are confirmed by an account manager.' });
});

server.registerTool('check_trading_rule', {
  title: 'Check a trading rule',
  description: "Checks whether an offered habitat can compensate for a lost habitat under the statutory metric's trading rules, and explains why.",
  inputSchema: { lost_habitat: z.string(), offered_habitat: z.string() },
  annotations: READ_ONLY,
}, async ({ lost_habitat, offered_habitat }) => {
  const r = tradingCheck(lookups, lost_habitat, offered_habitat);
  const lost = findHabitat(lookups, lost_habitat);
  audit('check_trading_rule', { lost_habitat, offered_habitat, ok: r.ok });
  return text({ ...r, lostDistinctiveness: lost ? lost.distinctiveness : null });
});

server.registerTool('spatial_risk', {
  title: 'Spatial risk multiplier',
  description: "Gives the spatial risk multiplier for buying units from a habitat bank for a site: 1 inside the bank's LPA or NCA, 0.75 for a neighbouring LPA or NCA listed on the bank's page, otherwise 0.5.",
  inputSchema: { site_lpa: z.string(), site_nca: z.string().optional(), bank_name: z.string() },
  annotations: READ_ONLY,
}, async ({ site_lpa, site_nca, bank_name }) => {
  const b = banks.find((x) => x.name.toLowerCase() === bank_name.toLowerCase());
  if (!b) { audit('spatial_risk', { site_lpa, bank_name, error: 'no such bank' }); return fail(new Error('No bank with that name in the list.')); }
  const r = spatialRisk({ lpa: site_lpa, nca: site_nca || '' }, b);
  audit('spatial_risk', { site_lpa, bank_name, multiplier: r.multiplier });
  return text({ bank: b.name, ...r });
});

server.registerTool('prepare_quote_brief', {
  title: 'Prepare a draft quote brief',
  description: 'Reads the metric, works out the shortfall against the net gain target and the trading deficits, shortlists habitat banks that satisfy the trading rules (best spatial multiplier first), lists the checks an account manager must make, and returns a draft brief. Draft only: it never prices, reserves or allocates units.',
  inputSchema: { file: z.string(), site_nca: z.string().optional() },
  annotations: READ_ONLY,
}, async ({ file, site_nca }) => {
  try {
    const m = await readMetric(safeMetricPath(file), { siteNca: site_nca || '' });
    const out = prepare(lookups, m, banks);
    audit('prepare_quote_brief', { file, deficits: out.requirement.deficits.length, stops: out.checks.filter((c) => c.level === 'stop').length });
    return text(out.brief + '\n---\n' + JSON.stringify({ requirement: out.requirement, checks: out.checks }, null, 2));
  } catch (e) { audit('prepare_quote_brief', { file, error: String(e.message) }); return fail(e); }
});

await server.connect(new StdioServerTransport());
