// End-to-end test over the real protocol: starts server.mjs on stdio with the official MCP client, lists the
// tools, runs every scenario through them and compares with eval/expected.json, then tries to break the
// folder guard. Writes eval/mcp-run.json (the results and a transcript of every call).
// Run from mcp/:  node --test integration.test.mjs
import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.join(here, '..');
const expected = JSON.parse(fs.readFileSync(path.join(root, 'eval/expected.json'), 'utf8')).cases;
const auditLog = path.join(os.tmpdir(), `bng-audit-${process.pid}.jsonl`);
const transcript = [];

async function connect() {
  const transport = new StdioClientTransport({
    command: process.execPath,
    args: [path.join(here, 'server.mjs')],
    env: { ...process.env, BNG_METRIC_DIR: path.join(root, 'tests/metrics'), BNG_AUDIT_LOG: auditLog },
    stderr: 'pipe',
  });
  const client = new Client({ name: 'bng-integration-test', version: '0.1.0' });
  await client.connect(transport);
  return client;
}
async function call(client, name, args) {
  const res = await client.callTool({ name, arguments: args });
  const text = res.content.map((c) => c.text).join('\n');
  transcript.push({ tool: name, arguments: args, isError: !!res.isError, text: text.length > 1600 ? text.slice(0, 1600) + '\n...' : text });
  return { res, text };
}

test('MCP server: tools, scenarios and guards', async () => {
  const client = await connect();
  const tools = (await client.listTools()).tools;
  const names = tools.map((t) => t.name).sort();
  assert.deepEqual(names, ['check_trading_rule', 'find_habitat_banks', 'list_metrics', 'prepare_quote_brief', 'read_metric', 'spatial_risk']);
  assert.ok(tools.every((t) => t.annotations && t.annotations.readOnlyHint === true), 'every tool is read-only');

  const listed = JSON.parse((await call(client, 'list_metrics', {})).text);
  assert.equal(listed.files.length, expected.length);

  const results = [];
  for (const e of expected) {
    const metric = JSON.parse((await call(client, 'read_metric', { file: e.file, site_nca: e.site_nca })).text);
    assert.ok(!JSON.stringify(metric).includes('Example Developer'), 'applicant name never read');
    assert.ok(!JSON.stringify(metric).includes('A. Ecologist'), 'author name never read');
    const { text } = await call(client, 'prepare_quote_brief', { file: e.file, site_nca: e.site_nca });
    const json = JSON.parse(text.split('\n---\n')[1]);
    const brief = text.split('\n---\n')[0];
    const row = { file: e.file, ok: true, problems: [] };
    for (const d of e.deficits) {
      const got = json.requirement.deficits.find((x) => x.label === d.label);
      if (!got || got.band !== d.band || got.units !== d.units) { row.ok = false; row.problems.push(`deficit ${d.label}: got ${JSON.stringify(got)}`); continue; }
      const best = brief.split('### ' + d.label)[1]?.split('\n')[1] || '';
      if (!best.startsWith('- ' + d.best)) { row.ok = false; row.problems.push(`best for ${d.label}: ${best.slice(0, 80)}`); }
      if (!best.includes(`Like for like: ${d.unitsToSource} units`)) { row.ok = false; row.problems.push(`units for ${d.label}: ${best.slice(-60)}`); }
    }
    for (const [type, s] of Object.entries(e.shortfall)) {
      if (json.requirement.types[type]?.shortfall !== s) { row.ok = false; row.problems.push(`${type} shortfall ${json.requirement.types[type]?.shortfall} vs ${s}`); }
    }
    const stops = json.checks.filter((c) => c.level === 'stop').length;
    if (stops !== e.stops) { row.ok = false; row.problems.push(`stops ${stops} vs ${e.stops}`); }
    for (const m of e.mustCheck) if (!json.checks.some((c) => c.text.includes(m))) { row.ok = false; row.problems.push(`missing check: ${m}`); }
    if (!brief.includes('Draft only')) { row.ok = false; row.problems.push('brief does not say it is a draft'); }
    results.push(row);
  }

  // Guards: the server must refuse anything outside its folder, and anything that is not .xlsx.
  const escape = await call(client, 'read_metric', { file: '../../data/habitat-banks.json' });
  const xlsm = await call(client, 'read_metric', { file: 'site.xlsm' });
  const missing = await call(client, 'read_metric', { file: 'not-there.xlsx' });
  const trading = JSON.parse((await call(client, 'check_trading_rule', { lost_habitat: 'Other neutral grassland', offered_habitat: 'Modified grassland' })).text);
  await client.close();

  const audit = fs.readFileSync(auditLog, 'utf8').trim().split('\n').map((l) => JSON.parse(l));
  const out = {
    ranAt: new Date().toISOString(), node: process.version, sdk: '@modelcontextprotocol/sdk 1.32.1', transport: 'stdio',
    tools: tools.map((t) => ({ name: t.name, title: t.title, readOnly: t.annotations?.readOnlyHint })),
    scenarios: results,
    guards: { pathEscapeRefused: escape.res.isError === true, xlsmRefused: xlsm.res.isError === true, missingFileRefused: missing.res.isError === true, tradeDownRefused: trading.ok === false },
    auditEntries: audit.length,
    transcript,
  };
  fs.writeFileSync(path.join(root, 'eval/mcp-run.json'), JSON.stringify(out, null, 2) + '\n');
  fs.rmSync(auditLog, { force: true });

  for (const r of results) assert.ok(r.ok, r.file + ': ' + r.problems.join('; '));
  assert.ok(out.guards.pathEscapeRefused && out.guards.xlsmRefused && out.guards.missingFileRefused && out.guards.tradeDownRefused);
  assert.equal(audit.length, transcript.length, 'every call is in the audit log');
});
