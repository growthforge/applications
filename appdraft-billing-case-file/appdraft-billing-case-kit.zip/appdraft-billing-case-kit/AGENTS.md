# AGENTS.md: the loop for an assistant working in this folder

1. Read `README.md` and the four files in `case/`.
2. Draft only what a stage prompt in `prompts/` asks for, into the matching file in `case/`.
3. Run `node check.mjs`. If it fails, fix the file it names and run it again. Do not edit `src/model.js` or `src/lint.js` to make a check pass; if you think a rule is wrong, stop and say so.
4. When `check.mjs` passes, stop and hand over to a person. Say which requirements are assumptions and which questions are still open. Never mark a requirement `confirmed` unless the call says it.
5. Never write the expected results in `tests.json` from the checker's output. They come from the rules in plain words.
6. Do not send anything to a client or a system. Nothing here is connected to Salesforce or Xero.
