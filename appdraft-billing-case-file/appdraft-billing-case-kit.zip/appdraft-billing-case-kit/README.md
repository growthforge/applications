# Billing case kit

An illustrative case file: an invented client call about a Salesforce and Xero billing project, written up as requirements, questions and checks, with a paperwork linter and a rule checker. Nothing here is connected to Salesforce or Xero, and the client is invented.

```
case/       call.json  requirements.json  gaps.json  tests.json   (the whole case, as data)
src/        model.js (the rules as small functions)  lint.js (the paperwork check)
prompts/    the four stages, each with the point where a person stops the line
check.mjs   one command: lint, coverage, rule checker; exits 1 on any failure
tests/      node --test   (the shipped case passes, four mutated copies fail)
AGENTS.md   the loop for an assistant: draft, check, fix, stop for a person
```

Needs Node 18 or later. No dependencies.

```
node check.mjs
node --test
node check.mjs --case ./another-case-folder
```

## What the checks do and do not prove
They prove the paperwork hangs together and the written rules agree with the written checks. They do not prove a build works: that is what a sandbox run with the client is for.

Xero tax types and statuses in `model.js` follow the public Xero developer documentation.
