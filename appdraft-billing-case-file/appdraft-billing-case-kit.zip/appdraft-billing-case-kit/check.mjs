// One command that reads the case and stops with a failure if anything is loose, untraced or untested.
//   node check.mjs                 checks ./case
//   node check.mjs --case ./draft  checks another folder with the same four files
import { createRequire } from 'node:module';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const here = path.dirname(fileURLToPath(import.meta.url));
const M = require('./src/model.js');
const L = require('./src/lint.js');
const i = process.argv.indexOf('--case');
const dir = path.resolve(i > -1 ? process.argv[i + 1] : path.join(here, 'case'));
const read = (f) => JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8'));
let c;
try { c = { call: read('call.json'), requirements: read('requirements.json'), gaps: read('gaps.json'), tests: read('tests.json') }; }
catch (e) { console.error('Cannot read the case in ' + dir + ': ' + e.message); process.exit(2); }

let failed = 0;
const say = (ok, msg) => { console.log((ok ? 'PASS  ' : 'FAIL  ') + msg); if (!ok) failed++; };

const problems = L.lint(c);
say(problems.length === 0, 'paperwork: ' + (problems.length ? problems.length + ' problem(s)' : 'every requirement has an actor, a trigger, a rule, a Given, When, Then and a source; no loose words'));
problems.forEach((p) => console.log('      ' + p.id + ': ' + p.msg));

const cov = L.coverage(c);
say(cov.untestedMust.length === 0, 'coverage: ' + (cov.untestedMust.length ? 'Must requirements with no test: ' + cov.untestedMust.join(', ') : 'every Must requirement has at least one check'));
say(cov.orphanTests.length === 0, 'traceability: ' + (cov.orphanTests.length ? 'checks that trace to no requirement: ' + cov.orphanTests.join(', ') : 'every check traces to a requirement'));
if (cov.untested.length) console.log('      (requirements with no check, any priority: ' + cov.untested.join(', ') + ')');

let bad = 0;
const results = c.tests.map((t) => M.runTest(t));
results.forEach((r) => { if (!r.pass) { bad++; console.log('      ' + r.id + ' fails: ' + r.cases.filter((x) => !x.pass).map((x) => x.name + ' ' + JSON.stringify(x.misses)).join('; ')); } });
say(bad === 0, 'rule checker: ' + (c.tests.length - bad) + ' of ' + c.tests.length + ' checks pass (' + results.reduce((n, r) => n + r.cases.length, 0) + ' cases)');

console.log('\n' + cov.counts.requirements + ' requirements (' + cov.counts.must + ' Must), ' + cov.counts.gaps + ' questions, ' + cov.counts.tests + ' checks.');
console.log(failed ? 'CHECK FAILED: ' + failed + ' problem area(s). Stop and fix before anything goes to the client.' : 'CHECK PASSED. A person still reads it before it goes anywhere.');
process.exit(failed ? 1 : 0);
