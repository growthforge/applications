# Stage 2: list what the call left open

> Read case/call.json and case/requirements.json. For every requirement marked assumption, and for anything the client contradicted themselves on, write a question. Each question has: id (G-01...), question, why (what goes wrong if it stays open), default (what we will do until they decide), decider (a role), blocks (the REQ ids it holds up), sources (line ids).
> Order them by how much they would change the design. Do not ask a question the call already answers.

**Gate:** a person chooses which questions are worth asking and writes the suggestion in their own words. A requirement marked assumption with no question fails `check.mjs`.
