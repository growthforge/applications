# Stage 4: check, then read

Run `node check.mjs`. It fails if a requirement has no source or no Given, When, Then, uses a loose word, is an assumption with no question, is a Must with no check, or if any check disagrees with the rules in `src/model.js`.

Then a person reads the whole case once, as the client would, before anything is sent. The command passing is a floor, not a verdict.
