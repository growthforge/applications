# Stage 3: write the checks in the client's words

> For each requirement, write one or more checks a client could run in a sandbox: id (TC-01...), title, requirements (REQ ids), steps (plain sentences, what to do and where to look), expected (what they should see).
> Do not write the expected values for the rule checker. A person writes those by hand.

**Gate:** the `fn` and `cases` (inputs and expected results) in `case/tests.json` are written by a person from the rules in plain words, before the rule checker is run. If the expected values are copied from what the checker printed, the check proves nothing.
