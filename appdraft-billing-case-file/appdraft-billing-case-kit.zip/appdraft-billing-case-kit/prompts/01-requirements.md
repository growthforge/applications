# Stage 1: draft the requirements from the call

Give an AI assistant `case/call.json` and this prompt. Then read every requirement against the lines it cites before it goes in `case/requirements.json`.

> You are drafting requirements for a Salesforce and Xero project from a discovery call transcript (JSON, each line has an id).
> For each requirement give: id (REQ-01...), title, actor, trigger, rule, plain (one sentence the client would recognise), sources (line ids), priority (Must, Should or Could), status (confirmed if the client said it, assumption if you inferred it), decider (a role on the client side), acceptance (a list of given, when, then, each with a real figure or example, never a placeholder such as [amount]), and gaps (ids of questions that would settle an assumption).
> Use only what the transcript supports. Do not rank everything Must: use Must only for what the client said must not fail. Do not turn an idea or a wish into a requirement. Do not use these words unless the same sentence gives a number or a time: fast, quick, easy, simple, soon, appropriate, flexible, robust, etc.
> Output JSON in the shape of case/requirements.json.

**Gate:** a person checks each requirement against the call and deletes anything the client did not say.
