import test from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const run = (args) => spawnSync(process.execPath, [path.join(root, 'check.mjs'), ...args], { encoding: 'utf8' });

test('the shipped case passes', () => { const r = run([]); assert.equal(r.status, 0, r.stdout + r.stderr); assert.match(r.stdout, /CHECK PASSED/); });

function mutated(fn) {
  const d = fs.mkdtempSync(path.join(os.tmpdir(), 'case-'));
  for (const f of ['call', 'requirements', 'gaps', 'tests']) fs.copyFileSync(path.join(root, 'case', f + '.json'), path.join(d, f + '.json'));
  fn(d, (f) => JSON.parse(fs.readFileSync(path.join(d, f + '.json'), 'utf8')), (f, o) => fs.writeFileSync(path.join(d, f + '.json'), JSON.stringify(o, null, 1)));
  return d;
}
test('a loose word fails the check', () => {
  const d = mutated((dir, get, put) => { const r = get('requirements'); r[0].rule = 'The sync should be quick.'; put('requirements', r); });
  const r = run(['--case', d]); assert.equal(r.status, 1); assert.match(r.stdout, /loose word "quick"/);
});
test('an untested Must fails the check', () => {
  const d = mutated((dir, get, put) => { const t = get('tests'); put('tests', t.filter((x) => !x.requirements.includes('REQ-09'))); });
  const r = run(['--case', d]); assert.equal(r.status, 1); assert.match(r.stdout, /REQ-09/);
});
test('a requirement with a source that is not in the call fails', () => {
  const d = mutated((dir, get, put) => { const r = get('requirements'); r[1].sources = ['L99']; put('requirements', r); });
  const r = run(['--case', d]); assert.equal(r.status, 1); assert.match(r.stdout, /L99/);
});
test('a rule that no longer matches its check fails', () => {
  const d = mutated((dir, get, put) => { const t = get('tests'); t.find((x) => x.id === 'TC-02').cases[0].expect.deposit = 500; put('tests', t); });
  const r = run(['--case', d]); assert.equal(r.status, 1); assert.match(r.stdout, /TC-02 fails/);
});
